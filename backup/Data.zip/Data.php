<?php

defined('BASEPATH') or exit('No direct script access allowed');

header('Access-Control-Allow-Origin: *');

Header('Access-Control-Allow-Headers: *'); //for allow any headers, insecure

Header('Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE');

header('content-type: application/json; charset=utf-8');



use Dompdf\Dompdf;



header("Access-Control-Allow-Origin: *");

require APPPATH . 'libraries/REST_Controller.php';

require APPPATH . 'config/gcm.php';

class Data extends REST_Controller

{



    /**

     * Create a new controller instance.

     *

     * @return void

     */

    public function __construct()

    {

        // Construct the parent class

        parent::__construct();

        $this->load->model('MainModel', 'MainModel', TRUE);

        $this->load->model('ApiModel', 'ApiModel', TRUE);

    }



    /**

     * Api get location office for app.

     *

     * @return void

     */







    public function index_post()

    {

        $key = $this->input->post('key');

        $result = $this->MainModel->getSettings();

        $data['key'] = $result->key_insert;



        if (!empty($key)) {

            if ($key == $data['key']) {



                // Get location

                $dataLocation = $this->ApiModel->getLocationArea();

                // Init the location

                $data = [

                    'message' => 'success',

                    'data' => $dataLocation

                ];

                // Check if data not empty

                if (count($data['data']) > 0) {

                    $this->response($data, REST_Controller::HTTP_OK);

                } else {

                    $this->response(['message' => 'empty', 'data' => 0], REST_Controller::HTTP_OK);

                }

            } else {

                $this->response(['message' => 'Your key is wrong'], REST_Controller::HTTP_OK);

            }

        } else {

            $this->response(['message' => 'Please insert your key first!'], REST_Controller::HTTP_OK);

        }

    }



    public function send_gcm_post()

    {

        // simple loading

        // note: you have to specify API key in config before

        $this->load->library('gcm');



        // simple adding message. You can also add message in the data,

        // but if you specified it with setMesage() already

        // then setMessage's messages will have bigger priority

        $this->gcm->setMessage('Test message ' . date('d.m.Y H:s:i'));



        // add recepient or few

        $this->gcm->addRecepient('fo99ZgnFQoSxZb46qZpRTy');

        //$this->gcm->addRecepient('New reg id');



        // set additional data

        $this->gcm->setData(array(

            'some_key' => 'some_val'

        ));



        // also you can add time to live

        $this->gcm->setTtl(500);

        // and unset in further

        $this->gcm->setTtl(false);



        // set group for messages if needed

        $this->gcm->setGroup('Test');

        // or set to default

        $this->gcm->setGroup(false);



        // then send

        if ($this->gcm->send())

            echo 'Success for all messages';

        else

            echo 'Some messages have errors';



        // and see responses for more info

        print_r($this->gcm->status);

        print_r($this->gcm->messagesStatuses);



        //die(' Worked.');

    }



    /**

     * Api get md5 location office.

     *

     * @return void

     */

    public function getMd5Location_post()

    {

        $key = $this->input->post('key');

        $result = $this->MainModel->getSettings();

        $data['key'] = $result->key_insert;



        if (!empty($key)) {

            if ($key == $data['key']) {



                // Get md5 from database

                $hashMd5 = $this->ApiModel->getMd5Location();

                $data = [

                    'message' => 'success',

                    'data' => $hashMd5

                ];

                $this->response($data, REST_Controller::HTTP_OK);

            } else {

                $this->response(['message' => 'Your key is wrong'], REST_Controller::HTTP_OK);

            }

        } else {

            $this->response(['message' => 'Please insert your key first!'], REST_Controller::HTTP_OK);

        }

    }

    /**

     * Api upload image and data.

     *

     * @return void

     */



    public function activity_post()

    {

        $inputJSON = file_get_contents('php://input');



        $input = json_decode($inputJSON, TRUE); //convert JSON into array





        $check = $this->ApiModel->getActivity();



        if ($check) {

            $response["status"] = 0;



            $response["message"] = "Activity successful";



            $response["data"] = $check;

        } else {



            $response["status"] = 1;



            $response["message"] = "invalid activity";

        }







        echo json_encode($check);

    }

    public function uploadPicActivity_post()

    {

        $img = $_POST['upload'];

        $type = $_POST['type'];

        $location = $_POST['location'];

        $site_location = $_POST['site_location'];

        $remark = $_POST['remark'];

        $user_id = $_POST['user_id'];

        $site_id = $_POST['site_id'];

        $date = $_POST['date'];

        $time = date("dmY") . time();

        $filename = "IMG" . $time . ".jpg";

        if (file_put_contents("public/uploads/" . $filename, base64_decode($img))) {



            $arr["img"] = $filename;

            $arr["type"] = $type;

            $arr["user_id"] = $user_id;

            $arr["location"] = $location;

            $arr["remark"] = $remark;

            $arr["site_id"] = $site_id;

            $arr["date"] = $date;

            $arr["site_location"] = $site_location;

            // Store the location

            $store = $this->ApiModel->uploadActivity($arr);

            // Check is stored

            if ($store) {

                $response = $store;

            } else {

                $response = "0";

            }

        }

        echo $response;

    }

    public function updateUserPass_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $arr["mobile"] = $input["mobile"];

        $arr["password"] = $input["password"];

        $result = $this->ApiModel->updateUserPass($arr);

        if ($result) {

            $response["status"] = 1;

            $response["message"] = "Success";

        } else {

            $response["status"] = 0;

            $response["message"] = "Mobile not found";

        }



        echo json_encode($response);

    }



    /**

     * Api get admin info.

     *

     * @return void

     */

    public function adminInfo_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $id = number_format($input['id']);

        $result = $this->ApiModel->adminInfo($id);

        $this->response($result, REST_Controller::HTTP_OK);

    }

    public function getUsername_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $mobile = $input['mobile'];

        // echo $mobile;

        $result = $this->ApiModel->getUsername($mobile);

        if ($result) {

            $response["status"] = 1;

            $response["username"] = $result->email;

        } else {

            $response["status"] = 0;

            $response["message"] = "Not find Username";

        }

        echo json_encode($response);

    }



    public function requestFund_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $cleanPost['site_id'] = $input["site_id"];

        $cleanPost['user_id'] = $input['user_id'];

        $cleanPost['amount'] = $input['amount'];

        $cleanPost['time'] = $input['time'];

        $cleanPost['date'] = $input['date'];

        $cleanPost['status'] = "0";

        $result = $this->ApiModel->requestFund($cleanPost);

        if ($result) {

            $response["status"] = 1;

            $response["message"] = "Successfully added";

            $response["id"] = $result;

        } else {

            $response["status"] = 1;

            $response["message"] = "Successfully added";

            $response["id"] = $result;

        }

        echo json_encode($response);

    }







    public function insertStock_post()

    {

        $inputJSON = file_get_contents('php://input');

        $row = json_decode($inputJSON, TRUE);

        //foreach ($input as $row) {

        $cleanPost['name'] = $row["name"];

        $cleanPost['brand'] = $row['brand'];

        $cleanPost['quantity'] = $row['quantity'];

        $cleanPost['unit'] = $row['unit'];

        $cleanPost['user_id'] = $row['user_id'];

        $cleanPost['site_id'] = $row['site_id'];

        $cleanPost['date'] = $row['date'];

        $result = $this->ApiModel->insertStock($cleanPost);

        //};

        if ($result) {

            $response["status"] = "1";

            $response["message"] = "Successfully added";

            $response["id"] = $result;

        } else {

            $response["status"] = "0";

            $response["message"] = "error";

        }

        echo json_encode($response);

    }

    public function insertStockRequest_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $cleanPost['name'] = $input["name"];

        $cleanPost['quantity'] = $input['quantity'];

        $cleanPost['user'] = $input['user'];

        $cleanPost['user_id'] = $input['user_id'];

        $cleanPost['site_id'] = $input['site_id'];

        $cleanPost['brand'] = $input['brand'];

        $cleanPost['date'] = $input['date'];

        $cleanPost['material_id'] = $input['material_id'];

        $result = $this->ApiModel->insertStockRequest($cleanPost);

        if ($result) {

            $response["status"] = 1;

            $response["message"] = "Successfully added";

            $response["id"] = $result;

        } else {

            $response["status"] = 1;

            $response["message"] = "Successfully added";

            $response["id"] = $result;

        }

        echo json_encode($response);

    }



    public function login_post()

    {

        $inputJSON = file_get_contents('php://input');



        $input = json_decode($inputJSON, TRUE); //convert JSON into array

        if (isset($input['username']) && isset($input['password'])) {



            $username = $input['username'];



            $password = $input['password'];



            $token = $input['token'];

            $check = $this->ApiModel->login($username, $password, $token);



            if ($check) {

                $response["status"] = 0;

                $response["message"] = "Login successful";

                $response["full_name"] = $check->first_name;

                $response["last_name"] = $check->last_name;

                $response["email"] = $check->email;

                $response["role"] = $check->role;

                $response["id"] = $check->id;

                $response["banned_users"] = $check->banned_users;

                $response["site_id"] = $check->site_id;

                $response["admin_id"] = $check->admin;

                $response["site_id"] = $check->site_id;

                $response["token"] = $check->token;

            } else {



                $response["status"] = 1;



                $response["message"] = "invalid username and password";

            }

        } else {



            $response["status"] = 2;



            $response["message"] = "Network Error";

        }

        echo json_encode($response);

    }









    /**

     * Api store new labour.

     *

     * @return message success of error

     */

    public function storeLabour_post()

    {

        $inputJSON = file_get_contents('php://input');



        $input = json_decode($inputJSON, TRUE); //convert JSON into array

        //        print_r($input);

        //		die();

        $labour = $input['labour'];

        $editedby = $input['editedby'];





        $cleanPost['name'] = $labour;

        $cleanPost['editedby'] = $editedby;



        // Store the location

        $store = $this->ApiModel->insertLabour($cleanPost);

        // Check is stored

        if ($store) {

            $data = [

                'message' => 'success',

                'status' => 0,

                'id' => $store,

            ];

        } else {

            $data = [

                'message' => 'error',

                'status' => 1,

            ];

        }

        // Return the result

        echo json_encode($data);

    }



    public function updateFundRequest_post()

    {

        $inputJSON = file_get_contents('php://input');



        $input = json_decode($inputJSON, TRUE); //convert JSON into array

        //        print_r($input);

        //		die();

        $id = $input['id'];

        $status = $input['status'];

        $cleanPost['id'] = $id;

        $cleanPost['status'] = $status;

        $store = $this->ApiModel->updateFundRequest($cleanPost);

        // Check is stored

        if ($store) {

            $data = [

                'message' => 'success',

                'status' => 0,

                'id' => $store,

            ];

        } else {

            $data = [

                'message' => 'error',

                'status' => 1,

            ];

        }

        // Return the result

        echo json_encode($data);

    }

    public function updateStoreRequest_post()

    {

        $inputJSON = file_get_contents('php://input');



        $input = json_decode($inputJSON, TRUE); //convert JSON into array

        $old_quantity = $this->ApiModel->checkStockData($input["material_id"]);

        // echo($old_quantity);

        $input["quantity"] = (int)$old_quantity + (int)$input["quantity"];

        // print_r($input);

        // die();

        $store = $this->ApiModel->updateStoreRequest($input);

        // Check is stored

        if ($store) {

            $data = [

                'message' => 'success',

                'status' => 0,

                'id' => $store,

            ];

        } else {

            $data = [

                'message' => 'error',

                'status' => 1,

            ];

        }

        // Return the result

        echo json_encode($data);

    }

    public function insertConsuption_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $input = $input["data"]; //convert JSON into array

        // print_r($input);

        // die();

        $arrlength = count($input);

        for ($x = 0; $x < $arrlength; $x++) {

            // print_r($input[$x]["id"]);

            // echo"===============";

            $old_quantity = $this->ApiModel->checkStockData($input[$x]["id"]);

            // echo("old $old_quantity new");

            $input[$x]["quantity"] = (int)$old_quantity - (int)$input[$x]["quantity"];

            // print_r($input[$x]["quantity"]);

            // echo" <br>";

        }



        $store = $this->ApiModel->insertConsuption($input);

        // Check is stored

        if ($store) {

            $data = [

                'message' => 'success',

                'status' => 0,

                'id' => $store,

            ];

        } else {

            $data = [

                'message' => 'error',

                'status' => 1,

            ];

        }

        $response = array('data' => $data);

        // Return the result

        echo json_encode($data);

    }









    /**

     * Api store new user.

     *

     * @return message success of error

     */

    public function storeUserInfo_post()

    {

        $inputJSON = file_get_contents('php://input');



        $input = json_decode($inputJSON, TRUE); //convert JSON into array



        $cleanPost['name'] = $input['full_name'];

        $cleanPost['mobile'] = $input['mobile'];

        $cleanPost['username'] =  $input['username'];

        $cleanPost['password'] = $input['password'];

        $cleanPost['site_id'] = $input['site_id'];

        $cleanPost['admin'] = $input['admin'];

        $cleanPost['role'] = $input['role'];



        // Store the location

        $store = $this->ApiModel->insertUserInfo($cleanPost);

      //  echo $store;



        // Check is stored

        if ($store) {

            $data = [

                'message' => 'success',

                'status' => 0,

                'id' => $store,

            ];

        } else {

            $data = [

                'message' => 'Usernamealready exixt',

                'status' => 1,

            ];

        }

        // Return the result

        echo json_encode($data);

    }







    /**

     * Api for fetching pic activity.

     *

     * @return message 

     */







    public function getpicActivity_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $cleanPost = $input;

        $store = $this->ApiModel->getpicActivity($cleanPost);

        // print_r($store); 

        $response["data"] = $store;

        $response["status"] = 1;

        echo json_encode($response);

        // $this->response($store, REST_Controller::HTTP_OK);

    }





    /**

     * Api for fetching pic activity.

     *

     * @return message 

     */







    public function getpicActivityBySiteId_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $cleanPost["site_id"] = $input["site_id"];

        $store = $this->ApiModel->getpicActivityBySiteId($cleanPost);

        // print_r($store); 

        $response["data"] = $store;

        $response["status"] = 1;

        echo json_encode($response);

        // $this->response($store, REST_Controller::HTTP_OK);

    }





    /**

     * Api for otp.

     *

     * @return message success of error90

     */

    public function otp_post()

    {

        $inputJSON = file_get_contents('php://input');



        $input = json_decode($inputJSON, TRUE); //convert JSON into array

        $name = $input['name'];

        $mobile = $input['mobile'];

        $base = "https://api.msg91.com/api/v5/otp?";

        $template = "615c350ef66e584866468d97";

        //$mobile="8766383794";

        $authkey = "338020AvQkfMOC2pzQ5f2b07d9P1";



        $curl = curl_init();



        curl_setopt_array($curl, array(

            CURLOPT_URL => $base . "template_id=" . $template . "&mobile=" . $mobile . "&authkey=" . $authkey,

            CURLOPT_RETURNTRANSFER => true,

            CURLOPT_ENCODING => "",

            CURLOPT_MAXREDIRS => 10,

            CURLOPT_TIMEOUT => 30,

            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,

            CURLOPT_CUSTOMREQUEST => "GET",

            CURLOPT_POSTFIELDS => "{\"Value1\":\"Param1\",\"Value2\":\"Param2\",\"Value3\":\"Param3\"}",

            CURLOPT_HTTPHEADER => array(

                "content-type: application/json"

            ),

        ));



        $response = curl_exec($curl);

        $err = curl_error($curl);



        curl_close($curl);



        if ($err) {

            echo "cURL Error #:" . $err;

        } else {

            echo $response;

        }

        //		 print_r($name);

        //		die();

        $cleanPost['name'] = $name;

        $cleanPost['mobile'] = $mobile;



        // Store the location

        $store = $this->ApiModel->otp($cleanPost);

        // Check is stored

        if ($store) {

            $data = [

                'message' => 'successfully sent on' . $mobile,

            ];

        } else {

            $data = [

                'message' => 'error',

            ];

        }

        // Return the result

        echo json_encode($response);

    }

    /*verify otp*/

    public function verifyOtp_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $otp = $input['otp'];

        $curl = curl_init();



        curl_setopt_array($curl, array(

            CURLOPT_URL => "https://api.msg91.com/api/v5/otp/verify?authkey=338020AvQkfMOC2pzQ5f2b07d9P1&mobile=8766383797&otp=9290&otp_expiry=5",

            CURLOPT_RETURNTRANSFER => true,

            CURLOPT_ENCODING => "",

            CURLOPT_MAXREDIRS => 10,

            CURLOPT_TIMEOUT => 30,

            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,

            CURLOPT_CUSTOMREQUEST => "GET",

        ));



        $response = curl_exec($curl);

        $err = curl_error($curl);



        curl_close($curl);



        if ($err) {

            echo "cURL Error #:" . $err;

        } else {

            echo $response;

        }



        echo json_encode($response);

    }



    /*resend otp*/

    public function resendOtp_post()

    {

        $inputJSON = file_get_contents('php://input');



        $input = json_decode($inputJSON, TRUE); //convert JSON into array

        $mobile = $input['mobile'];

        $curl = curl_init();



        curl_setopt_array($curl, array(

            CURLOPT_URL => "https://api.msg91.com/api/v5/otp/retry?authkey=338020AvQkfMOC2pzQ5f2b07d9P1&retrytype=text&mobile=918766383794",

            CURLOPT_RETURNTRANSFER => true,

            CURLOPT_ENCODING => "",

            CURLOPT_MAXREDIRS => 10,

            CURLOPT_TIMEOUT => 30,

            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,

            CURLOPT_CUSTOMREQUEST => "GET",

        ));



        $response = curl_exec($curl);

        $err = curl_error($curl);



        curl_close($curl);



        if ($err) {

            echo "cURL Error #:" . $err;

        } else {

            echo $response;

        }

    }





    public function storeLocation_post()

    {

        $lat = $this->input->post('lat');

        $longt = $this->input->post('longt');



        $cleanPost['lat'] = $lat;

        $cleanPost['longt'] = $longt;



        // Store the location

        $store = $this->ApiModel->insertLocation($cleanPost);

        // Check is stored

        if ($store) {

            $data = [

                'message' => 'success',

            ];

        } else {

            $data = [

                'message' => 'error',

            ];

        }

        // Return the result

        $this->response($data, REST_Controller::HTTP_OK);

    }



    /**

     * Api delete location office.

     *

     * @return void

     */

    public function deleteLocationTable_post()

    {

        // Delete the location

        $this->ApiModel->deleteTableLocation();

    }



    /**

     * Api get the location office.

     *

     * @return void

     */

    public function showAllDataLocation_get()

    {

        $data = $this->ApiModel->getLocationArea();

        // Return the json

        $this->response($data, REST_Controller::HTTP_OK);

    }



    /**

     * Api store the md5 location office.

     *

     * @return void

     */

    public function storeMd5Location_post()

    {

        $md5 = $this->input->post('md5');

        $hashMd5 = md5($md5);



        $cleanPost['md5'] = $hashMd5;

        // Store new md5

        $this->ApiModel->insertMd5($cleanPost);

    }



    /**

     * Api for attendance check-in or check-out.

     *

     * @return void

     */

    public function absent_attendance_post()

    {

        if ($this->input->server('REQUEST_METHOD') == 'POST') {



            // Get key from request

            $key = $this->input->post('key');



            // Get settings data

            $result = $this->MainModel->getSettings();

            $data['many_employee'] = $result->many_employee;

            $data['start'] = $result->start_time;

            $data['out'] = $result->out_time;

            $data['key'] = $result->key_insert;



            // Check if key not empty

            if (!empty($key)) {

                if ($key == $data['key']) {



                    $Q = $this->security->xss_clean($this->input->post('q', TRUE));

                    $name = $this->security->xss_clean($this->input->post('name', TRUE));

                    $date = $this->security->xss_clean($this->input->post('date', TRUE));

                    $location = $this->security->xss_clean($this->input->post('location', TRUE));



                    // Check command is in our out

                    if ($Q == 'in') {



                        $in_time = $this->security->xss_clean($this->input->post('in_time', TRUE));

                        $change_in_time = strtotime($in_time);



                        // Get late time

                        $get_late_time = $this->getTime($change_in_time - strtotime($data['start']));

                        $late_time = "$get_late_time[0]:$get_late_time[1]:$get_late_time[2]";



                        $allData = array(

                            'name' => $name,

                            'date' => $date,

                            'in_location' => $location,

                            'in_time' => $in_time,

                            'late_time' => $late_time

                        );



                        $insertData = $this->MainModel->insertAbsent($allData);

                        if ($insertData == true) {

                            echo 'Success!';

                        } else {

                            echo 'Error! Something Went Wrong!';

                        }

                    } else if ($Q == 'out') {



                        $out_time = $this->security->xss_clean($this->input->post('out_time', TRUE));

                        $change_out_time = strtotime($out_time);



                        // Open in_time from database

                        $getDataIn['in_time'] = $this->MainModel->getDataAbsent('name', $name, 'date', $date);

                        $get_in_database = strtotime($getDataIn['in_time']);



                        // Get work hour

                        $get_work_hour = $this->getTime($change_out_time - $get_in_database);

                        $work_hour = "$get_work_hour[0]:$get_work_hour[1]:$get_work_hour[2]";



                        // Get over time

                        $get_over_time = $this->getTime($change_out_time - strtotime($data['out']));

                        if ($get_in_database > strtotime($data['out']) || $change_out_time < strtotime($data['out'])) {

                            $over_time = '00:00:00';

                        } else {

                            $over_time = "$get_over_time[0]:$get_over_time[1]:$get_over_time[2]";

                        }



                        // Early out time

                        $get_early_out_time = $this->getTime(strtotime($data['out']) - $change_out_time);

                        if ($get_in_database > strtotime($data['out'])) {

                            $early_out_time = '00:00:00';

                        } else {

                            $early_out_time = "$get_early_out_time[0]:$get_early_out_time[1]:$get_early_out_time[2]";

                        }



                        // Add data

                        $allData = array(

                            'name' => $name,

                            'date' => $date,

                            'out_location' => $location,

                            'out_time' => $out_time,

                            'work_hour' => $work_hour,

                            'over_time' => $over_time,

                            'early_out_time' => $early_out_time

                        );



                        $updateData = $this->MainModel->updateAbsent($allData);

                        if ($updateData == true) {

                            echo 'Success!';

                        } else {

                            echo 'Error! Something Went Wrong!';

                        }

                    } else {

                        echo 'Error! Wrong Command!';

                    }

                } else {

                    echo 'The KEY is Wrong!';

                }

            } else {

                echo 'Please Setting KEY First!';

            }

        } else {

            echo "You can't access this page!";

        }

    }



    /**

     * Function get time.

     *

     * @param $total

     * @return array

     */

    public function getTime($total)

    {

        $hours = (int)($total / 3600);

        $seconds_remain = ($total - ($hours * 3600));

        $minutes = (int)($seconds_remain / 60);

        $seconds = ($seconds_remain - ($minutes * 60));

        return array($hours, $minutes, $seconds);

    }







    // getting all the pending request data

    public function getPendingRequest_post()

    {



        $sucess =  $this->ApiModel->getPendingRequest();

        $this->response($sucess, REST_Controller::HTTP_OK);

    }







    // react js api by asif

    public function getPendingRequestBySiteId_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $site_id = $input["site_id"];

        $result = $this->ApiModel->getPendingRequestBySiteId($site_id);



        if ($result) {

            $response["status"] = 1;

            $response["data"] = $result;

        } else {

            $response["status"] = 0;

            $response["data"] = "Id not found !";

        }



        echo json_encode($response);

    }









    public function getFundRequest_post()

    {



        $sucess =  $this->ApiModel->getFundRequest();

        $this->response($sucess, REST_Controller::HTTP_OK);

    }

    // accepting pending data using user id

    public function acceptPendingRequest_post()

    {



        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $id = $input["id"];

        $result = $this->ApiModel->acceptPendingRequest($id);



        if ($result) {

            $response["status"] = 1;

            $response["message"] = "Updated Pending Request Successfully";

        } else {

            $response["status"] = 0;

            $response["message"] = "Id not found !";

        }



        echo json_encode($response);

    }





    // rejecting user request by user id

    public function rejectPendingRequest_post()

    {



        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $id = $input["id"];

        $result = $this->ApiModel->rejectPendingRequest($id);



        if ($result) {



            $response["status"] = 1;

            $response["message"] = "Updated Reject Request Successfully";

        } else {

            $response["status"] = 0;

            $response["message"] = "Id not found !";

        }



        echo json_encode($response);

    }



    public function getReceivingData_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $site_id = $input["site_id"];

        $datefrom = $input["datefrom"];

        $dateto = $input["dateto"];

        if ($dateto == "0" && $datefrom == "0") {

            $result =  $this->ApiModel->getReceivingData($site_id);

        } else {

            $result =  $this->ApiModel->getReceivingSearchData($site_id, $datefrom, $dateto);

        }

        if ($result) {



            $response["status"] = 1;

            $response["data"] = $result;

        } else {

            $response["status"] = 0;

            $response["message"] = "Id not found !";

        }

        echo json_encode($response);

    }
	
	 public function getReceivingPdf_post()

    {
		 require 'vendor/autoload.php';

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);
		
        $site_id = $input["site_id"];

        $datefrom = $input["datefrom"];

        $dateto = $input["dateto"];

        if ($dateto == "0" && $datefrom == "0") {

            $result =  $this->ApiModel->getReceivingData($site_id);

        } else {

           $pic_data = $this->ApiModel->getReceivingData($site_id,$datefrom,$dateto);
//		print_r($pic_data);
//			die();

        $html = $this->load->view('report/statement', array('pic' => $pic_data), true);

        
		$dompdf = new Dompdf();

        // Load HTML content 

        $dompdf->loadHtml($html);

        // $dompdf->loadHtml('<h1>Welcome to CodexWorld.com</h1>');



        // (Optional) Setup the paper size and orientation 

        $dompdf->setPaper('A4', 'portrait');



        // Render the HTML as PDF 

        $dompdf->render();

        // $dompdf->

        // Output the generated PDF to Browser 

        $output = $dompdf->output();



        $result=file_put_contents("public/uploads/statement.pdf", $output);


        }

        if ($result) {



            $response["status"] = 1;

            $response["data"] = $result;

        } else {

            $response["status"] = 0;

            $response["message"] = "Id not found !";

        }

        echo json_encode($response);

    }
	
	public function getExpensePdf_post()

    {
		 require 'vendor/autoload.php';

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);
		
        $site_id = $input["site_id"];

        $datefrom = $input["datefrom"];

        $dateto = $input["dateto"];

        if ($dateto == "0" && $datefrom == "0") {

            $result =  $this->ApiModel->getExpenses($site_id);

        } else {

            $pic_data =  $this->ApiModel->getExpensesData($site_id, $datefrom, $dateto);
//		print_r($pic_data);
//			die();

        $html = $this->load->view('report/statement', array('pic' => $pic_data), true);

        
		$dompdf = new Dompdf();

        // Load HTML content 

        $dompdf->loadHtml($html);

        // $dompdf->loadHtml('<h1>Welcome to CodexWorld.com</h1>');



        // (Optional) Setup the paper size and orientation 

        $dompdf->setPaper('A4', 'portrait');



        // Render the HTML as PDF 

        $dompdf->render();

        // $dompdf->

        // Output the generated PDF to Browser 

        $output = $dompdf->output();



        $result=file_put_contents("public/uploads/statement.pdf", $output);


        }

        if ($result) {



            $response["status"] = 1;

            $response["data"] = $result;

        } else {

            $response["status"] = 0;

            $response["message"] = "Id not found !";

        }

        echo json_encode($response);

    }



    public function swapAdmin_post(){

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $admin_id =$input["admin_id"];

        $user_id =$input["user_id"];

        // print_r($input);

        // die();

        $result =  $this->ApiModel->swapAdmin($admin_id,$user_id);

        if ($result) {



            $response["status"] = 1;

            $response["data"] = $result;

        } else {

            $response["status"] = 0;

            $response["message"] = "Server errorr";

        }

        echo json_encode($response);

    }





    // ================ stock section =============================



    // getting all the stock data

    public function getStockData_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $site_id = $input["site_id"];

        $result =  $this->ApiModel->getStockData($site_id);

        if ($result) {



            $response["status"] = 1;

            $response["data"] = $result;

        } else {

            $response["status"] = 0;

            $response["message"] = "Id not found !";

        }

        echo json_encode($response);

    }



    // updating  stock data

    public function  updateStockRequest_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        //checking for already in list 

        $id=$input["id"];

         $quantity =(int)$input["quantity"] ;

         $result =  $this->ApiModel->updateStockRequest($id, $quantity);

         if ($result) {

            $response["status"] = 1;

            $response["message"] = "Successfully Updated";

        } else {

            $response["status"] = 0;

            $response["message"] = "Update failed!";

        }

        // $this->response($response, REST_Controller::HTTP_OK);

        echo json_encode($response);

    }





    // ================ unit section =============================

    public function getUnits_get()

    {



        $sucess =  $this->ApiModel->getUnits();

        $this->response($sucess, REST_Controller::HTTP_OK);

    }







    // ================ manpower section =============================



    public function insertManpower_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $site_id = $input["site_id"];

        $user_id = $input["user_id"];

        $edited_by = $input["edited_by"];

        $date = $input["date"];

        if (is_array($input) || is_object($input)) {

            foreach ($input["data"] as $row) {



                $cleanPost['name'] = $row["name"];

                $cleanPost['skilled'] = $row['skilled'];

                $cleanPost['unskilled'] = $row['unskilled'];

                $cleanPost['edited_by'] = $edited_by;

                $cleanPost['user_id'] = $user_id;

                $cleanPost['site_id'] = $site_id;

                $cleanPost['date'] = $date;

                $result = $this->ApiModel->insertManpower($cleanPost);

            };

        };

        if ($result) {



            $cleanPost1['total_skilled'] = $input['totalSkilled'];

            $cleanPost1['total_unskilled'] = $input['totalUnSkilled'];

            $cleanPost1['edited_by'] = $edited_by;

            $cleanPost1['user_id'] = $user_id;

            $cleanPost1['site_id'] = $site_id;

            $cleanPost1['date'] = $date;

            $result = $this->ApiModel->insertTotalManpower($cleanPost1);

            if ($result) {

                $response["status"] = 1;

                $response["result"] = $result;

            }

        } else {

            $response["status"] = 0;

        }



        echo json_encode($response);

    }



    public function getTotalManpower_post()

    {



        // die();

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        if ($input["site_id"] == "0") {

            $data = $this->ApiModel->getSiteIdByUserId($input['user_id']);

            $site_id = $data->site_id;

        } else {

            $site_id = $input["site_id"];

        }

        $result = $this->ApiModel->getTotalManpower($site_id);







        if ($result) {

            $response["status"] = 1;

            $response["data"] = $result;

        } else {

            $response["status"] = 0;

            $response["data"] = $site_id;

            $response["message"] = "Id not found !";

        }

        echo json_encode($response);

    }





    public function getManpowerByDate_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $site_id = (int)$input["site_id"];

        $date = $input["date"];

        // echo json_encode($cleanPost);

        // die();

        $result = $this->ApiModel->getManpowerByDate($site_id, $date);

        if ($result) {

            $data["data"] = $result;

            $data["status"] = 1;

        } else {

            $data["status"] = 0;

        }



        echo json_encode($data);

        die();



        if ($result) {



            $response["status"] = 1;

            $response["data"] = $result;

        } else {

            $response["status"] = 0;

            $response["message"] = "Id not found !";

        }

        echo json_encode($response);

    }









    // ============================== site info=================================================



    public function insertSite_post()

    {

        $inputJSON = file_get_contents('php://input');



        $input = json_decode($inputJSON, TRUE);



        $cleanPost["name"] = $input["name"];

        $cleanPost["location"] = $input["location"];

        $cleanPost["members"] = $input["members"];

        $cleanPost["user_id"] = $input["user_id"];

        $result = $this->ApiModel->insertSite($cleanPost);
        if ($result) {
            
            $response["status"] = 1;

            // $response["message"] = "Site Added Successfully";



        } else {

            $response["status"] = 0;

            // $response["message"] = "Something went wrong. Try Again !";

        }

        echo json_encode($response);

    }

    // api to fetch site data by user id

    public function getSiteById_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $user_id = $input["id"];

        $result = $this->ApiModel->getSiteById($user_id);



        if ($result) {



            $response["status"] = 1;

            $response["data"] = $result;

        } else {

            $response["status"] = 0;

            $response["message"] = "Id not found !";

        }



        echo json_encode($response);

    }





    // api to fetch site users  by site id

    public function getUsersBySiteId_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $id = $input["id"];

        $result = $this->ApiModel->getUsersBySiteId($id);

        if ($result) {

            $response["status"] = 1;

            $response["data"] = $result;

        } else {

            $response["status"] = 0;

            $response["message"] = "Id not found !";

        }

        echo json_encode($response);

    }









    // ================== day book receiving=======================

    public function insertReceiving_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $cleanPost["by_whom"] = $input["by_whom"];

        $cleanPost["username"] = $input["username"];

        $cleanPost["amount"] = $input["amount"];

        $cleanPost["site_id"] = $input["site_id"];

        $cleanPost["user_id"] = $input["user_id"];

        $cleanPost["date"] = $input["date"];

        $result = $this->ApiModel->insertReceiving($cleanPost);

        if ($result) {

            $response["status"] = 1;

            $response["message"] = "receiving Added Successfully";

        } else {

            $response["status"] = 0;

            $response["message"] = "Something went wrong. Try Again !";

        }

        echo json_encode($response);

    }





    public function getReceiving_post()

    {

        $inputJSON = file_get_contents('php://input');
        $input = json_decode($inputJSON, TRUE);

        $site_id = $input["site_id"];
      

        $result = $this->ApiModel->getReceiving($site_id);
 
        if ($result) {

            $response["status"] = 1;
            $response["data"] = $result;

        } else {

            $response["status"] = 0;
            $response["message"] = "Id not found !";

        }

        echo json_encode($response);

    }


    // ================== day book expenses=======================

    public function insertExpenses_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $cleanPost["by_whom"] = $input["by_whom"];

        $cleanPost["username"] = $input["username"];

        $cleanPost["amount"] = $input["amount"];

        $cleanPost["site_id"] = $input["site_id"];

        $cleanPost["user_id"] = $input["user_id"];

        $cleanPost["date"] = $input["date"];

        $result = $this->ApiModel->insertExpenses($cleanPost);

        if ($result) {

            $response["status"] = 1;

            $response["message"] = "receiving Added Successfully";

        } else {

            $response["status"] = 0;

            $response["message"] = "Something went wrong. Try Again !";

        }

        echo json_encode($response);

    }





    public function getExpenses_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $site_id = $input["site_id"];

        $datefrom = $input["datefrom"];

        $dateto = $input["dateto"];

        if ($dateto == "0" && $datefrom == "0") {

            $result =  $this->ApiModel->getExpenses($site_id);

        } else {

            $result =  $this->ApiModel->getExpensesData($site_id, $datefrom, $dateto);

        }

        if ($result) {



            $response["status"] = 1;

            $response["data"] = $result;

        } else {

            $response["status"] = 0;

            $response["message"] = "Id not found !";

        }

        echo json_encode($response);

    }

    public function getTotalExpensesRecieving_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $site_id = $input["site_id"];

        $expenses =  $this->ApiModel->getTotalExpenses($site_id);

        $recieving =  $this->ApiModel->getTotalReceiving($site_id);
        
        //   print_r($sucess->amount);

        if ($expenses->amount || $recieving->amount) {

            $response["status"] = 1;

            $response["expense"] = $expenses->amount;

            $response["recieving"] = $recieving->amount;
            $response["data"] = array("expenses" => $expenses->amount, "recieving" => $recieving->amount);

        } else {

            $response["status"] = 1;

        }

        echo json_encode($response);

    }


public function getTodayAttendance_post(){
        $inputJSON = file_get_contents('php://input');
        $input = json_decode($inputJSON, TRUE);
	date_default_timezone_set('Asia/Kolkata');
	 $date = date('Y-m-d');
        $result = $this->ApiModel->getTodayAttendance($date);

        if($result){
            $response["status"] = 1;
            $response["data"] = $result;
        
        }else{
            $response["status"] = 0;
            $response["data"] = "Something went wrong";
        }

        echo json_encode($response);
    }


    public function getAttendanceBySiteId_post(){
        $inputJSON = file_get_contents('php://input');
        $input = json_decode($inputJSON, TRUE);
        $site_id = $input["site_id"];
        $datefrom = $input["datefrom"];
        $dateto = $input["dateto"];
		
        if ($dateto == "0" && $datefrom == "0") {
            $result = $this->ApiModel->getAttendanceBySiteId($site_id);
           
        } else {
            $result =  $this->ApiModel->getAttendanceByDate($site_id, $datefrom, $dateto);
        }

        if($result){
            $response["status"] = 1;
            $response["data"] = $result;
        
        }else{
            $response["status"] = 0;
            $response["data"] = "Something went wrong";
        }

        echo json_encode($response);
    }











    // ------------------------ web react js api starts here -------------------------

    // ------------------------ web react js api starts here -------------------------

    // ------------------------ web react js api starts here -------------------------

    // ------------------------ web react js api starts here -------------------------

    // ------------------------ web react js api starts here -------------------------



    public function addNewUser_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);



        $cleanPost["first_name"] = $input["first_name"];

        $cleanPost["last_name"] = $input["last_name"];

        $cleanPost["email"] = $input["email"];

        $cleanPost["role"] = $input["role"];

        $cleanPost["site_id"] = $input["site_id"];

        $cleanPost["status"] = $input["status"];

        $cleanPost["banned_users"] = $input["banned_users"];

        $cleanPost["password"] = $input["password"];



        $result = $this->ApiModel->addNewUser($cleanPost);



        if ($result) {



            $response["status"] = 1;

            $response["data"] = "User added Successfully";

        } else {

            $response["status"] = 0;

            $response["data"] = "Some error occured while addding new user";

        }





        echo json_encode($response);

    }





    public function getAllUsers_post()

    {

        $result = $this->ApiModel->getAllUsers();

        $this->response($result, REST_Controller::HTTP_OK);

    }



    public function getUserDetailsById_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $user_id = $input["id"];

        $result = $this->ApiModel->getUserDetailsById($user_id);

        if ($result) {



            $response["status"] = 1;

            $response["data"] = $result;

        } else {

            $response["status"] = 0;

            $response["data"] = "user not found! Try again Later";

        }





        echo json_encode($response);

    }







    // updating user by ud

    public function updateUserById_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);



        $cleanPost['id'] = $input["id"];

        $cleanPost["first_name"] = $input["first_name"];

        $cleanPost["last_name"] = $input["last_name"];

        $cleanPost["email"] = $input["email"];

        $cleanPost["role"] = $input["role"];

        $cleanPost["status"] = $input["status"];

        $cleanPost["banned_users"] = $input["banned_users"];



        $result = $this->ApiModel->updateUserById($cleanPost);

        // if($result){

        //     $response["status"] = 1;

        //     $response["data"] = "User updated successfully";

        // }else{

        //     $response["status"] = 0;

        //     $response["data"] = "Something went wrong";

        // }



        echo json_decode($result);

    }



    public function deleteUserById_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $id = $input["id"];

        $result = $this->ApiModel->deleteUserById($id);

        // if($result){

        //     $response["status"] = 1;

        //     $response["data"] = "User deleted successfully";

        // }else{

        //     $response["status"] = 0;

        //     $response["data"] = "Something went wrong";

        // }



        echo json_decode($result);

    }





    // update admin profile

    public function updateUserDetails_post()

    {



        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);



        $cleanPost["id"] = $input["id"];

        $cleanPost["first_name"] = $input["first_name"];

        $cleanPost["last_name"] = $input["last_name"];

        $cleanPost["email"] = $input["email"];



        $result = $this->ApiModel->updateUserDetails($cleanPost);



        if ($result) {

            $response["status"] = 1;

            $response["data"] = "User updated successfully";

        } else {

            $response["status"] = 0;

            $response["data"] = "User updated unsucessfully";

        }

        echo json_encode($response);

    }





    // getting user details by id this is define by two ti

    public function getUserDetails_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $id = $input["id"];

        $result = $this->ApiModel->getUserDetails($id);

        if ($result) {

            $response["status"] = 1;

            $response["data"] = $result;

        } else {

            $response["status"] = 0;

            $response["data"] = "Something went wrong";

        }

        echo json_encode($response);

    }





    // getting manpower details by id

    public function getManpowerDetails_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $id = $input["id"];

        $result = $this->ApiModel->getManpowerDetails($id);

        if ($result) {

            $response["status"] = 1;

            $response["data"] = $result;

        } else {

            $response["status"] = 0;

            $response["data"] = "Something went wrong";

        }

        echo json_encode($response);

    }



    // getting stock details by site_id

    public function getStockDetails_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $id = $input["id"];

        $result = $this->ApiModel->getStockDetails($id);

        if ($result) {

            $response["status"] = 1;

            $response["data"] = $result;

        } else {

            $response["status"] = 0;

            $response["data"] = "Something went wrong";

        }

        echo json_encode($response);

    }



    public function getPicDetails_post()

    {

        require 'vendor/autoload.php';



        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $id = $input["id"];

        $pic_data = $this->ApiModel->getPicDetails($id);

        $html = $this->load->view('sitepictures/download_sitepicture', array('pic' => $pic_data), true);



        $dompdf = new Dompdf();

        // Load HTML content 

        $dompdf->loadHtml($html);

        // $dompdf->loadHtml('<h1>Welcome to CodexWorld.com</h1>');



        // (Optional) Setup the paper size and orientation 

        $dompdf->setPaper('A4', 'landscape');



        // Render the HTML as PDF 

        $dompdf->render();

        // $dompdf->

        // Output the generated PDF to Browser 

        $output = $dompdf->output();



        $result = file_put_contents("public/uploads/file.pdf", $output);



        if ($result) {

            $response["status"] = 1;

            $response["data"] = "Success";

        } else {

            $response["status"] = 0;

            $response["data"] = "Something went wrong";

        }

        echo json_encode($response);

    }











    public function uploadLoginSelfie_post()

    {

        $img = $_POST['pic'];

        $date = $_POST['date'];

        $time = $_POST['time'];

        $name = $_POST['name'];

        $attempt = $_POST['attempt'];

        $user_id = $_POST['user_id'];

        $site_id = $_POST['site_id'];

        $longi = $_POST['longi'];

        $lati = $_POST['lati'];

        $location = $_POST['location'];

        // print_r ($arr);

        // die();

        $time1 = date("dmY") . time();

        $filename = "IMG" . $time1 . ".jpg";

        if (file_put_contents("public/login_selfie/" . $filename, base64_decode($img))) {

            $arr["img"] = $filename;

            $arr["date"] = $date;

            $arr["user_id"] = $user_id;

            $arr["time"] = $time;

            $arr["name"] = $name;

            $arr["site_id"] = $site_id;

            $arr["attempt"] = $attempt;

            $arr["longi"] = $longi;

            $arr["lati"] = $lati;

            $arr["location"] = $location;

            // Store the location



            $store = $this->ApiModel->uploadLoginSelfie($arr);

            // Check is stored

            if ($store) {

                $response = "1";

            } else {

                $response = "0";

            }

        }

        echo ($response);

    }

    function getUserByAdminId_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $admin = $input["admin"];

        $result = $this->ApiModel->getUserByAdminId($admin);

        if ($result) {

            $response["status"] = 1;

            $response["data"] = $result;

        } else {

            $response["status"] = 0;

            $response["message"] = "Id not found !";

        }

        echo json_encode($response);

    }

    function banUser_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $id = $input["id"];

        $result = $this->ApiModel->banUser($id);

        if ($result) {

            $response["status"] = 1;

            $response["message"] = "Id banned !";

        } else {

            $response["status"] = 0;

            $response["message"] = "Id not found !";

        }

        echo json_encode($response);

    }

    function getAdminName_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $id = $input["id"];

        $result = $this->ApiModel->getAdminName($id);

        if ($result) {

            $response["status"] = 1;
            $response["data"] = $result;
            $response["message"] = "success !";

        } else {

            $response["status"] = 0;

            $response["message"] = "error !";

        }

        echo json_encode($response);

    }

    function unBanUser_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $id = $input["id"];

        $result = $this->ApiModel->unBanUser($id);

        if ($result) {

            $response["status"] = 1;

            $response["message"] = "Id Unbanned !";

        } else {

            $response["status"] = 0;

            $response["message"] = "Id not found !";

        }

        echo json_encode($response);

    }





    public function getPicByDate_post()

    {

        $inputJSON = file_get_contents('php://input');

        $input = json_decode($inputJSON, TRUE);

        $site_id = $input["site_id"];

        $datefrom = $input["datefrom"];

        $dateto = $input["dateto"];

        $result =  $this->ApiModel->getPicByDate($site_id, $datefrom, $dateto);

        if ($result) {



            $response["status"] = 1;

            $response["data"] = $result;

        } else {

            $response["status"] = 0;

            $response["message"] = "Id not found !";

        }

        echo json_encode($response);

    }

}
