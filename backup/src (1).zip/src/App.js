import "./App.css";
import Dashboard from "./home/Dashboard";
import Attendance from "./components/attendance/Attendance";
import Daybook from "./components/daybook/Daybook";
import Site from "./sites/Site";
import { Routes, Route, Switch } from "react-router-dom";
import NavbarComponent from "./components/navbar-component/Navbar";
import Footer from "./components/footer-component/Footer";
import Members from "./sites/view_members";
import Manpower from "./sites/view_manpower";
import Stock from "./sites/view_stock";
import StockRequest from "./sites/view_stockrequest";
import SitePictures from "./sites/view_sitepictures";
import Authentication from "./authentication/authentication";
import Login from "./authentication/login/Login";
import Home from "./home/Home";
import Profile from "./user/profile";
import ForgotPassword from "./authentication/forgot_password/forgot_password";
import {useNavigate } from 'react-router-dom';

function App() {

  const navigate = useNavigate();
  
  return (
    <div>
      {
      sessionStorage.getItem("isLoggedIn") === "true" 
        ? <Home /> 
        :  <Routes>
        <Route exact path="/login" element={<Login />} />
        <Route  path="/"  redirectTo="/login" element={<Login />} />
        <Route  name="forgot_password" path="forgot_password" element={<ForgotPassword />} /> 
    </Routes>
      }

      
    </div>
  );
}

export default App;
