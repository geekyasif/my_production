import React from 'react'

export default function Stock() {
    return (
        <div>
            <p>This is stock page</p>
        </div>
    )
}
