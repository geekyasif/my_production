import React from "react";
import { useState } from "react";
import NavLogo from "../../assets/logo512.png";
import baseUrl from "../../components/base_url/baseUrl";
import { useNavigate } from "react-router-dom";
import "./login.css";
import { Link } from "react-router-dom";
import { db } from "../../services/firebase";
import {
  collection,
  addDoc,
  doc,
  updateDoc,
  query,
  where,
  getDocs,
  setDoc,
  CollectionReference,
  usersCollectionRef,
} from "firebase/firestore/lite";

export default function Login() {
  const [username, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    const response = await fetch(`${baseUrl}api/data/login`, {
      method: "POST",
      body: JSON.stringify({ username: username, password: password }),
    });

    const json = await response.json();

    // localstorage ya  session storage
    console.log(json);
    if (json["status"] === 0) {
      sessionStorage.setItem("isLoggedIn", "true");
      sessionStorage.setItem("username", json["full_name"]);
      sessionStorage.setItem("user_id", json["id"]);
      sessionStorage.setItem("email", json["email"]);
      sessionStorage.setItem("phone", json["last_name"]);
      sessionStorage.setItem("role", json["role"]);
      sessionStorage.setItem("admin", json["admin_id"]);
      sessionStorage.setItem("site_id", json["site_id"]);

      //     // i have to set user information in session storage and redirect to dashboard
      const isLoggedIn = sessionStorage.getItem("isLoggedIn");
      const username = sessionStorage.getItem("username");
      const user_id = sessionStorage.getItem("user_id");
      const email = sessionStorage.getItem("email");
      const phone = sessionStorage.getItem("phone");
      const role = sessionStorage.getItem("role");
      const admin = sessionStorage.getItem("admin");
      const site_id = sessionStorage.getItem("site_id");

      if (role !== "1") {

        await setDoc(doc(db, "attendance", username), {
          isLoggedIn: isLoggedIn,
          username: username,
          user_id: user_id,
          email: email,
          phone: phone,
          role: role,
          admin: admin,
          site_id: site_id,
        });
        console.log("addded");

      }

      navigate("/dashboard");
    } else {
      alert("Inavlid Credential");
    }

    setUserName("");
    setPassword("");

  };

  return (
    <div className="loginMainContainer">
      <div className="container py-4 text-center ">
        <div className="row py-4 ">
          <div className="center-vertical ">
            <div className=" container col-lg-4 shadow-sm bg-light rounded py-3">
              <div className="row">
                <div className="col-md-8">
                  {" "}
                  <h2>VconstructHome</h2>
                  <h5>Please Login.</h5>
                </div>{" "}
                <div className="col-md-4">
                  <img src={NavLogo} width="80" />
                </div>
              </div>
              <hr />
              <form
                onSubmit={handleSubmit}
                className="form-signin"
                method="post"
                accept-charset="utf-8"
              >
                <div className="form-group my-2">
                  <input
                    type="text"
                    name="email"
                    value={username}
                    onChange={(e) => setUserName(e.target.value)}
                    id="email"
                    placeholder="Email"
                    className="form-control"
                  />
                </div>
                <div className="form-group my-2">
                  <input
                    type="password"
                    name="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    id="password"
                    placeholder="Password"
                    className="form-control"
                  />
                </div>
                <div class="d-grid gap-2">
                  <button class="btn btn-primary" type="submit">
                    Let me in!
                  </button>
                </div>
              </form>
              <br />
              <p>
                <small>
                  {" "}
                  Forgot your password?
                  <Link to="/forgot_password">Forgot Password</Link>
                </small>
              </p>
              <hr />
              Copyright© - 2021 | Create by
              <a href="https://vconstructhome.com/"> VconstructHome</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
