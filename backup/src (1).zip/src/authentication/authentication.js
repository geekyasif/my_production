import React from 'react'
import { Routes, Route, Switch } from "react-router-dom";
import Login from './login/Login';
import ForgotPassword from './forgot_password/forgot_password'

export default function authentication() {
    return (
        <div>
           
        </div>
    )
}
