import React from 'react'
import {useState} from 'react';
import { useNavigate } from 'react-router';
import NavLogo from '../../assets/logo512.png';
import { Link } from 'react-router-dom';


export default function ForgotPassword() {
    const [email, setEmail] = useState("");

    const navigate = useNavigate();

    const handleSubmit = async (e) => {
      e.preventDefault();
  
      const authEmail = {
        email: email,
     
      };
  
      console.log(authEmail);
  
      // const response = await fetch(`${baseUrl}api/data/login`, {
      //     method: "POST",
      //     headers:{
      //         'Content-Type' : 'application/json'
      //     },
      //     body: JSON.stringify({authEmail})
      // });
  
      // const json = await response.json()
      // // localstorage ya  session storage
      // console.log(json);
      // if(json.sucess){
      //     // i have to set user information in session storage and redirect to dashboard
      //     navigate("/");
      // }else{
      //     alert("Inavlid Credential")
      // }
  
      setEmail("");
  
      if (email === "asifgmail.com" ) {
        // sessionStorage.setItem("isLoggedIn", "true");
        // sessionStorage.setItem("username", "Mohammad Asif");
        // sessionStorage.setItem("email", "mdasif08737@gmail.com");
        // sessionStorage.setItem("phone", "1234567");
        // sessionStorage.setItem("role", '1');
        // sessionStorage.setItem("admin", '2');
        // sessionStorage.setItem("site_id" , "0");
  
        window.location.reload();
        navigate("/");
      } else {
        console.log("error");
        alert("Inavlid Credential");
      }
    };

    return (
        <div>
                <div className="loginMainContainer">
      <div className="container py-4 text-center ">
        <div className="row py-4 ">
          <div className="center-vertical ">
            <div className=" container col-lg-4 shadow-sm bg-light rounded py-3">
              <div className="row">
                <div className="col-md-8">
                  {" "}
                  <h2>Forgot Password</h2>
                  <small>Please enter your email address and we'll send you instructions on how to reset your password</small>
                </div>{" "}
                <div className="col-md-4">
                  <img src={NavLogo} width="80" />
                </div>
              </div>
              <hr />
              <form
                onSubmit={handleSubmit}
                className="form-signin"
                method="post"
                accept-charset="utf-8"
              >
                <div className="form-group my-2">
                  <input
                    type="text"
                    name="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    id="email"
                    placeholder="Email"
                    className="form-control"
                  />
                </div>
                <div class="d-grid gap-2">
                <button class="btn btn-primary" type="submit">Send Mail</button>
              </div>
           
              </form>
              <br />
              <p>
                <small>  Already have an account ?
                <Link to="/login">
                  Login
                </Link></small>
              </p>
              <hr />
              Copyright© - 2021 | Create by
              <a href="https://vconstructhome.com/"> VconstructHome</a>
            </div>
          </div>
        </div>
      </div>
    </div>
        </div>
    )
}
