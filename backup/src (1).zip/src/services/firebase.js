import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs } from 'firebase/firestore/lite';

const firebaseConfig = {
    apiKey: "AIzaSyAV4PBHutID5rnT4Gv4ggE8ZyQ5_hMTMMk",
    authDomain: "vconstructhome.firebaseapp.com",
    projectId: "vconstructhome",
    storageBucket: "vconstructhome.appspot.com",
    messagingSenderId: "694189322856",
    appId: "1:694189322856:web:067e117a32cc7c95a941dd",
    measurementId: "G-X83K8MXZH2"
  };

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export {db};


