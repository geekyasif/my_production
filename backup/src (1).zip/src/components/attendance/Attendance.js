import React from "react";
import DataTable from "react-data-table-component";
import Checkbox from "@material-ui/core/Checkbox";
import ArrowDownward from "@material-ui/icons/ArrowDownward";
import { useState, useEffect } from "react";
import axios from "axios";
import Datatable from "datatables.net";

export default function Attendance() {
  const [attendance, setAttendance] = useState([]);
  const sortIcon = <ArrowDownward />;
  const selectProps = { indeterminate: (isIndeterminate) => isIndeterminate };
  const columns = [
    {
      name: "No.",
      selector: (row) => row.title,
    },
    {
      name: "Name",
      selector: (row) => row.year,
    },
    {
      name: "Date",
      selector: (row) => row.title,
    },
    {
      name: "In Time",
      selector: (row) => row.year,
    },
    {
      name: "Out Time",
      selector: (row) => row.title,
    },
    {
      name: "Work Hour",
      selector: (row) => row.year,
    },
    {
      name: "Over Time",
      selector: (row) => row.title,
    },
    {
      name: "Late Time",
      selector: (row) => row.year,
    },
    {
      name: "Early Time Out",
      selector: (row) => row.year,
    },
    {
      name: "In Location",
      selector: (row) => row.year,
    },
    {
      name: "Out Location",
      selector: (row) => row.year,
    },
  ];

  const data = [
    {
      id: 1,
      title: "Beetlejuice",
      year: "1988",
    },
    {
      id: 2,
      title: "Ghostbusters",
      year: "1984",
    },
  ];

  useEffect(() => {
    async function fetchAttendance() {
      const request = await axios
        .post("https://admin.vconstructhome.com/panel/api/data/getStockData")
        .then(function (response) {
          console.log(response.data);
          setAttendance(response.data);
        })
        .catch(function (error) {
          console.log(error);
        });

      return request;
    }

    fetchAttendance();
  }, []);

  return (
    <div className="container my-5 py-5">
      <h1 className="mb-5">User Attendance</h1>

      <DataTable
        key={attendance.id}
        pagination
        selectableRowsComponent={Checkbox}
        selectableRowsComponentProps={selectProps}
        sortIcon={sortIcon}
        dense
        columns={columns}
        data={attendance}
      />
    </div>
  );
}
