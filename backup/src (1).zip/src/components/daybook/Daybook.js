import React from "react";
import DataTable from "react-data-table-component";
import Checkbox from "@material-ui/core/Checkbox";
import ArrowDownward from "@material-ui/icons/ArrowDownward";

export default function Daybook() {
  const sortIcon = <ArrowDownward />;
  const selectProps = { indeterminate: (isIndeterminate) => isIndeterminate };

  const columns = [
    {
      name: "No.",
      selector: (row) => row.title,
    },
    {
      name: "Name",
      selector: (row) => row.year,
    },
    {
      name: "Date",
      selector: (row) => row.title,
    },
    {
      name: "In Time",
      selector: (row) => row.year,
    },
    {
      name: "Out Time",
      selector: (row) => row.title,
    },
    {
      name: "Work Hour",
      selector: (row) => row.year,
    },
    {
      name: "Over Time",
      selector: (row) => row.title,
    },
    {
      name: "Late Time",
      selector: (row) => row.year,
    },
    {
      name: "Early Time Out",
      selector: (row) => row.year,
    },
    {
      name: "In Location",
      selector: (row) => row.year,
    },
    {
      name: "Out Location",
      selector: (row) => row.year,
    },
  ];

  const data = [
    {
      id: 1,
      title: "Beetlejuice",
      year: "1988",
    },
    {
      id: 2,
      title: "Ghostbusters",
      year: "1984",
    },
  ];

  return (
    <div className="container my-5">
      <h1 className="mb-5">Daybook</h1>
      <DataTable
        pagination
        selectableRowsComponent={Checkbox}
        selectableRowsComponentProps={selectProps}
        sortIcon={sortIcon}
        dense
        columns={columns}
        data={data}
      />
    </div>
  );
}
