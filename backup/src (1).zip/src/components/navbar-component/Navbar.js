import React from "react";
import { Link } from "react-router-dom";
import NavLogo from "../../assets/logo512.png";
import { useNavigate } from "react-router-dom";
import { Nav, Navbar, Container, NavDropdown } from "react-bootstrap";
import { db } from "../../services/firebase";
import {
  collection,
  addDoc,
  doc,
  updateDoc,
  query,
  where,
  getDocs,
  setDoc,
  CollectionReference,
  usersCollectionRef,
} from "firebase/firestore/lite";

export default function NavbarComponent() {
  const navigate = useNavigate();

  async function logout() {
    const username = sessionStorage.getItem("username");
    const user_id = sessionStorage.getItem("user_id");
    const email = sessionStorage.getItem("email");
    const phone = sessionStorage.getItem("phone");
    const role = sessionStorage.getItem("role");
    const admin = sessionStorage.getItem("admin");
    const site_id = sessionStorage.getItem("site_id");

    await setDoc(doc(db, "attendance", username), {
      isLoggedIn: "false",
      username: username,
      user_id: user_id,
      email: email,
      phone: phone,
      role: role,
      admin: admin,
      site_id: site_id,
    });
    console.log("addded");

    sessionStorage.clear();
    navigate('/login');
  }

  return (
    <div>
      <Navbar bg="dark" variant="dark" expand="lg">
        <Container>
          <Link className="navbar-brand" to="/dashboard">
            <img
              className="d-inline-block align-top"
              width="80"
              height="50"
              alt=""
              src={NavLogo}
            />
          </Link>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <ul className="navbar-nav mx-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <Link className="nav-link" aria-current="page" to="/dashboard">
                  Dashboard
                </Link>
              </li>

              {sessionStorage.getItem("role") === "0" ? (
                <NavDropdown title="Users" id="basic-nav-dropdown">
                  <NavDropdown.Item>
                    <Link className="nav-link text-dark" to="/user_list">
                      Users
                    </Link>
                  </NavDropdown.Item>
                  <NavDropdown.Item>
                    <Link className="nav-link text-dark" to="/add_user">
                      Add Users
                    </Link>
                  </NavDropdown.Item>
                </NavDropdown>
              ) : (
                  <li className="nav-item">
                    <Link className="nav-link" to="/sites">
                      Sites
                    </Link>
                  </li>
              )}
            </ul>
            <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
              <NavDropdown
                title={sessionStorage.getItem("username")}
                id="basic-nav-dropdown"
              >
                <NavDropdown.Item href="#action/3.1">
                  {sessionStorage.getItem("email")}
                </NavDropdown.Item>
                <NavDropdown.Item>
                  <Link className="nav-link text-dark" to="/profile">
                    Edit Profile
                  </Link>
                </NavDropdown.Item>
                <NavDropdown.Divider />
                <NavDropdown.Item onClick={logout}>
                  <Link className="nav-link text-dark" to="/login">
                    Logout
                  </Link>
                </NavDropdown.Item>
              </NavDropdown>
            </ul>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </div>
  );
}
