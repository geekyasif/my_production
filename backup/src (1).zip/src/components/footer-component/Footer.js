import React from 'react'

export default function Footer() {
    return (
        <div>
            <footer className="footer mt-auto py-3 bg-light fixed-bottom">
                <div className="container">
                    <span className="text-muted">VconstructHome.com</span>
                </div>
            </footer>
        </div>
    )
}
