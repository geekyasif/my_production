import React from "react";
import { CSVLink, CSVDownload } from "react-csv";
import Button from "@restart/ui/esm/Button";
import Spreadsheet from "react-spreadsheet";
import { Document, Page } from "react-pdf";
import ReactExport from "react-data-export";
import { ExportSheet } from 'react-xlsx-sheet'
import XLSX from 'xlsx';
import { jsPDF } from "jspdf";
import { render } from 'react-dom'
import ReactDOM from 'react-dom';
import ReactDOMServer from 'react-dom/server';


export default function ExportTableData(props) {
    // var doc = new jsPDF();
  
    // const pdfDown = ()=> {
    //   doc.fromHTML(ReactDOMServer.renderToStaticMarkup(render()));
    //   doc.save("myDocument.pdf");
    // }
  
  return (
    <div>
      <CSVLink data={props.data}>
        <Button className="btn btn-secondary border my-3">Download Excel</Button>
      </CSVLink>
      {/* <ExportSheet
        header={props.columns}
        fileName="site"
        dataSource={props.data}
        xlsx={XLSX}
      >
        <Button className="btn btn-secondary border my-3 mx-2">Excel</Button>
      </ExportSheet>

      <Button className="btn btn-secondary border my-3 mx-2" onClick={pdfDown}>PDF</Button> */}
    </div>
  );
}
