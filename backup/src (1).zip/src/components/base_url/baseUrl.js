
// const baseURL = "https://admin.vconstructhome.com/panel/";

const baseURL = "http://192.168.1.13/panel/";

export default baseURL;