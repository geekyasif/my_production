import React from "react";
import { Routes, Route, Switch } from "react-router-dom";
import Dashboard from "./Dashboard";
import Attendance from "../components/attendance/Attendance";
import Daybook from "../components/daybook/Daybook";
import Site from "../sites/Site";
import NavbarComponent from "../components/navbar-component/Navbar";
import Footer from "../components/footer-component/Footer";
import Members from "../sites/view_members";
import Manpower from "../sites/view_manpower";
import Stock from "../sites/view_stock";
import StockRequest from "../sites/view_stockrequest";
import SitePictures from "../sites/view_sitepictures";
import Profile from "../user/profile";
import ForgotPassword from "../authentication/forgot_password/forgot_password";
import Login from "../authentication/login/Login";
import UserList from "../user/UserList";
import AddUser from "../user/AddUser";
import EditUser from "../user/edit_user";
import EditMember from "../sites/edit_member";
import EditManpower from "../sites/edit_manpower";
import EditStock from "../sites/edit_stock";
import EditStockRequest from "../sites/edit_stockrequest";
import UserSites from "../user/view_userSites";
import BanUser from "../user/ban_user";
import PicDetails from "../sites/view_pic_details";

export default function Home() {
  return (
    <div>
      <NavbarComponent />
      <Routes>
        <Route exact path="/dashboard" element={<Dashboard />} />
        <Route  path="/"  redirectTo="/dashboard" element={<Dashboard />} />
        <Route path="profile" element={<Profile />} />
        <Route path="user_list" element={<UserList />} />
        <Route path="user_list/view_sites/:id" element={<UserSites />} />
        <Route path="/add_user" element={<AddUser />} />
        <Route path="/user_list/edit_user/:userId" element={<EditUser />} />
        <Route path="/user_list/ban_user/:userId" element={<BanUser />} />
        <Route path="/attendance" element={<Attendance />} />
        <Route path="/daybook" element={<Daybook />} />
        <Route path="/sites" element={<Site />} />
        <Route
          name="view_members"
          path="sites/view_members/:siteId"
          element={<Members />}
        />
        <Route
          name="view_members"
          path="sites/view_members/edit_member/:id"
          element={<EditMember />}
        />

        <Route
          name="view_manpower"
          path="sites/view_manpower/:siteId"
          element={<Manpower />}
        />
        
        <Route
          name="view_manpower"
          path="sites/view_manpower/edit_manpower/:id"
          element={<EditManpower />}
        />

        <Route
          name="view_sitepictures"
          path="sites/view_sitepictures/:siteId"
          element={<SitePictures />}
        />
        <Route
          name="view_sitepictures"
          path="sites/view_pic_details/:id"
          element={<PicDetails />}
        />
        <Route
          name="view_stock"
          path="sites/view_stock/:siteId"
          element={<Stock />}
        />
                <Route
          name="view_manpower"
          path="sites/view_stock/edit_stock/:id"
          element={<EditStock />}
        />

        <Route
          name="view_stockrequest"
          path="sites/view_stockrequest/:siteId"
          element={<StockRequest />}
        />
                <Route
          name="view_stockrequest"
          path="sites/view_stockrequest/edit_stockrequest/:id"
          element={<EditStockRequest />}
        />
      </Routes>
  
      <Footer />
      <Routes>
        <Route
          name="forgot_password"
          path="forgot_password"
          element={<ForgotPassword />}
        />
      </Routes>
    </div>
  );
}
