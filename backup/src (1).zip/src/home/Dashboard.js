import React from "react";
import { useState, useEffect } from "react";
import { db } from "../services/firebase";
import {
  collection,
  addDoc,
  doc,
  updateDoc,
  query,
  where,
  getDocs,
  setDoc,
  CollectionReference,
  usersCollectionRef,
} from "firebase/firestore/lite";

export default function Dashboard() {
  const [userAttendance, setUserAttendance] = useState([]);
  const user_id = sessionStorage.getItem("user_id");
  const userData = [];

  useEffect(() => {
    async function getUserInfo() {
      const q = query(
        collection(db, "attendance"),
        where("admin", "==", user_id)
      );

      const querySnapshot = await getDocs(q);
      querySnapshot.forEach((doc) => {
        userData.push(doc.data());
      });
      setUserAttendance(userData);
    }

    getUserInfo();
  }, [userData]);

  const userCard = {
    border: "1px solid black",
    padding: "20px",
  };

  return (
    <div className="container">
      <div className="container bg-light my-5 py-5 rounded-3">
        <h1>Hi, {sessionStorage.getItem("username")}</h1>
        <h5>Welcome back! How are you Today?</h5>
      </div>

      <div className="timeline">
        <h3>Timeline</h3>
        <hr />

        {userAttendance.map((user) => (
          <div style={userCard}>
            <h5>Name :- {user["username"]}</h5>
            <p>
              Status :-{" "}
              {user["isLoggedIn"] === "true" ? (
                <span>Online</span>
              ) : (
                <span>Ofline</span>
              )}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
