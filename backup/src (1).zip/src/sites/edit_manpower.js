import React from "react";
import { useParams } from "react-router";
import baseUrl from "../components/base_url/baseUrl";
import { useState, useEffect } from "react";

export default function EditManpower() {
  let { id } = useParams();
  const [manpowerDetails, setManpowerDetails] = useState([]);


  useEffect(() => {
    async function fetchUserDetails() {
      const response = await fetch(`${baseUrl}api/data/getManpowerDetails`, {
        method: "POST",
        body: JSON.stringify({ id: id }),
      });
      console.log(`${baseUrl}api/data/getManpowerDetails`);
      const json = await response.json();
      console.log(json["data"][0]);
      console.log("printing value from api");
      setManpowerDetails(json["data"][0]);
    }

    fetchUserDetails();
  }, []);

  return (
    <div>
      <h2 className="text-center my-4">Edit Manpower</h2>
      <div class="row">
        <div class="col-lg-4 col-lg-offset-4 mx-auto">
          <h2>Edit Member</h2>
          <hr />
          <form class="form-signin" method="post" accept-charset="utf-8">
            <div class="form-group">
              <input
                type="text"
                name="firstname"
                value={manpowerDetails["name"]}
                id="firstname"
                placeholder="First Name"
                class="form-control"
              />
            </div>{" "}
            <div class="form-group">
              <input
                type="text"
                name="lastname"
                value={manpowerDetails["skilled"]}
                id="lastname"
                placeholder="Last Name"
                class="form-control"
              />
            </div>{" "}
            <div class="form-group">
              <input
                type="text"
                name="lastname"
                value={manpowerDetails["unskilled"]}
                id="lastname"
                placeholder="Last Name"
                class="form-control"
              />
            </div>
            <input
              type="submit"
              value="Submit"
              class="btn btn-lg btn-primary btn-block"
            />
          </form>
        </div>
      </div>
    </div>
  );
}
