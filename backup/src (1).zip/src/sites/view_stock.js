import React from "react";
import DataTable from "react-data-table-component";
import Checkbox from "@material-ui/core/Checkbox";
import { useState, useEffect } from "react";
import { useParams } from "react-router";
import baseUrl from "../components/base_url/baseUrl";
import ExportTableData from "../components/export-table-data/ExportTableData";
import ArrowDownward from "@material-ui/icons/ArrowDownward";
import { Link } from "react-router-dom";

// site picture api is pending

export default function Stock() {
  let { siteId } = useParams();
  const [stocks, setStocks] = useState([]);

  const sortIcon = <ArrowDownward />;
  const selectProps = { indeterminate: (isIndeterminate) => isIndeterminate };

  const columns = [
    {
      name: "No.",
      selector: (row) => row.id,
    },
    {
      name: "Name",
      selector: (row) => row.name,
    },
    {
      name: "Brand",
      selector: (row) => row.brand,
    },
    {
      name: "Quantity",
      selector: (row) => row.quantity,
    },
    {
      name: "Unit",
      selector: (row) => row.unit,
    },
    {
      name: "Edit",
      selector: (row) => row.id,
      cell: (row) => (
        <Link
          to={`/sites/view_stock/edit_stock/${row.id}`}
          className="btn btn-primary btn-sm"
        >
          Edit
        </Link>
      ),
    },
  ];

  useEffect(() => {
    async function fetchStockData() {
      const response = await fetch(`${baseUrl}api/data/getStockData`, {
        method: "POST",
        body: JSON.stringify({ site_id: siteId.toString() }),
      });
      console.log(`${baseUrl}api/data/getStockData`);
      const json = await response.json();
      if (json["status"] == 1) {
        setStocks(json["data"]);
      } else {
        setStocks([]);
      }
    }

    fetchStockData();
  }, []);

  return (
    <div className="">
      <h1 className="text-center my-4">Stocks List</h1>
      <ExportTableData data={stocks} columns={columns} />
      <DataTable
        key={stocks ? stocks.id : siteId}
        pagination
        selectableRowsComponent={Checkbox}
        selectableRowsComponentProps={selectProps}
        sortIcon={sortIcon}
        dense
        columns={columns}
        data={stocks}
      />
    </div>
  );
}
