import React from "react";
import DataTable from "react-data-table-component";
import Checkbox from "@material-ui/core/Checkbox";
import { useState, useEffect } from "react";
import { useParams } from "react-router";
import baseUrl from "../components/base_url/baseUrl";
import ExportTableData from "../components/export-table-data/ExportTableData";
import ArrowDownward from "@material-ui/icons/ArrowDownward";
import { Link } from "react-router-dom";

export default function Members() {
  let { siteId } = useParams();
  const [members, setMembers] = useState([]);

  const sortIcon = <ArrowDownward />;
  const selectProps = { indeterminate: (isIndeterminate) => isIndeterminate };

  const columns = [
    {
      name: "No.",
      selector: (row) => row.id,
    },
    {
      name: "Name",
      selector: (row) => row.first_name,
    },
    {
      name: "Email",
      selector: (row) => row.email,
    },
    {
      name: "Phone Number",
      selector: (row) => row.last_name,
    },
    {
      name: "Edit",
      selector: (row) => row.id,
      cell: (row) => (
        <Link
          to={`/sites/view_members/edit_member/${row.id}`}
          className="btn btn-primary btn-sm"
        >
          Edit
        </Link>
      ),
    },
  ];

  useEffect(() => {
    async function fetchUsersBySiteId() {
      const response = await fetch(`${baseUrl}api/data/getUsersBySiteId`, {
        method: "POST",
        body: JSON.stringify({ id: siteId.toString() }),
      });
      console.log(`${baseUrl}api/data/getUsersBySiteId`);
      const json = await response.json();
      console.log(json["data"]);
      setMembers(json["data"]);
    }

    fetchUsersBySiteId();
  }, []);

  return (
    <div className="">
      <h1 className="text-center my-4">Members List</h1>
      <ExportTableData data={members} columns={columns} />
      <DataTable
        key={members.id}
        pagination
        selectableRowsComponent={Checkbox}
        selectableRowsComponentProps={selectProps}
        sortIcon={sortIcon}
        dense
        columns={columns}
        data={members}
      />
    </div>
  );
}
