import React from "react";
import DataTable from "react-data-table-component";
import Checkbox from "@material-ui/core/Checkbox";
import { useState, useEffect } from "react";
import { useParams } from "react-router";
import baseUrl from "../components/base_url/baseUrl";
import ExportTableData from "../components/export-table-data/ExportTableData";
import ArrowDownward from "@material-ui/icons/ArrowDownward";
import { Link } from "react-router-dom";
// site picture api is pending

export default function StockRequest() {
  let { siteId } = useParams();
  const [stockRequests, setStockRequests] = useState([]);

  const sortIcon = <ArrowDownward />;
  const selectProps = { indeterminate: (isIndeterminate) => isIndeterminate };

  const columns = [
    {
      name: "No.",
      selector: (row) => row.id,
    },
    {
      name: "Name",
      selector: (row) => row.name,
    },
    {
      name: "Quantity",
      selector: (row) => row.quantity,
    },
    {
      name: "User",
      selector: (row) => row.user,
    },
    {
      name: "Date",
      selector: (row) => row.date,
    },
    {
      name: "Status",
      selector: (row) => row.status,
    },
  ];



    // accept pending request function but button is not created
  async function acceptRequest(id) {
    const response = await fetch(`${baseUrl}api/data/acceptPendingRequest`, {
      method: "POST",
      body: JSON.stringify({ id: id.toString() }),
    });
    console.log(`${baseUrl}api/data/acceptPendingRequest`);
    const json = await response.json();
    console.log(json);
  }




  // fetching all the data using api
  useEffect(() => {
    async function fetchUsersBySiteId() {
      const response = await fetch(
        `${baseUrl}api/data/getPendingRequestBySiteId`,
        {
          method: "POST",
          body: JSON.stringify({ site_id: siteId.toString() }),
        }
      );
      console.log(`${baseUrl}api/data/getStockData`);
      const json = await response.json();
      console.log(json);
      setStockRequests(json["data"]);
    }

    fetchUsersBySiteId();
  }, []);


  return (
    <div className="">
      <h1 className="text-center my-4">Stock Request</h1>
      <ExportTableData data={stockRequests} columns={columns} />
      <DataTable
        key={stockRequests.id}
        pagination
        selectableRowsComponent={Checkbox}
        selectableRowsComponentProps={selectProps}
        sortIcon={sortIcon}
        dense
        columns={columns}
        data={stockRequests}
      />
    </div>
  );
}
