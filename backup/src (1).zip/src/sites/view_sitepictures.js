import React from "react";
import DataTable from "react-data-table-component";
import Checkbox from "@material-ui/core/Checkbox";
import ArrowDownward from "@material-ui/icons/ArrowDownward";
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useParams } from "react-router";
import baseURL from "../components/base_url/baseUrl";
import ExportTableData from "../components/export-table-data/ExportTableData";

// site picture api is pending

export default function SitePictures() {
  let { siteId } = useParams();
  const [pictures, setPictures] = useState([]);

  const sortIcon = <ArrowDownward />;
  const selectProps = { indeterminate: (isIndeterminate) => isIndeterminate };

  const columns = [
    {
      name: "No.",
      selector: (row) => row.id,
    },
    {
      name: "Site Location",
      selector: (row) => row.site_location,
    },
    {
      name: "Type",
      selector: (row) => row.type,
    },
    {
      name: "Activity",
      selector: (row) => row.location,
    },
    {
      name: "Remark",
      selector: (row) => row.remark,
    },
    {
      name: "Date & Time",
      selector: (row) => row.date,
    },
    {
      name: "Picture",
      selector: (row) => row.img,
      cell: (row) => (
        <img
          className="img-fluid"
          src={`${baseURL}public/uploads/${row.img}`}
        />
      ),
    },
    {
      name: "Picture Details",
      selector: (row) => row.id,
      cell: (row) => (
        <Link
          className="btn btn-danger btn-sm"
          to={`/sites/view_pic_details/${row.id}`}
        >
          View Picture
        </Link>
      ),
    },
  ];

  useEffect(() => {
    async function fetchUsersBySiteId() {
      const response = await fetch(
        `${baseURL}api/data/getpicActivityBySiteId`,
        {
          method: "POST",
          body: JSON.stringify({ site_id: siteId.toString() }),
        }
      );
      console.log(`${baseURL}api/data/getpicActivityBySiteId`);
      const json = await response.json();
      console.log(json["data"]);
      setPictures(json["data"]);
    }

    fetchUsersBySiteId();
  }, []);

  return (
    <div className="">
      <h1 className="text-center my-4">Site Pictures</h1>
      <ExportTableData data={pictures} columns={columns} />
      <DataTable
        key={pictures.id}
        pagination
        selectableRowsComponent={Checkbox}
        selectableRowsComponentProps={selectProps}
        sortIcon={sortIcon}
        dense
        columns={columns}
        data={pictures}
      />
    </div>
  );
}
