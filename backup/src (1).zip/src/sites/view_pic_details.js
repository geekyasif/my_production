import React from 'react'
import {useState, useEffect} from 'react'
import { useParams } from 'react-router'
import baseUrl from '../components/base_url/baseUrl'
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import ReactDOMServer from "react-dom/server";



export default function PicDetails() {
    const {id} = useParams();
    const[picDetails, setPicDetails] = useState([]);

    useEffect(() => {
        const getPicDetails = async ()=> {
            const response = await fetch(`${baseUrl}api/data/getPicDetails`, {
                method: "POST",
                body: JSON.stringify({ id: id.toString() }),
              });
              console.log(`${baseUrl}api/data/getPicDetails`);
              const json = await response.json();
              console.log(json["data"][0])
              setPicDetails(json["data"][0]);
              
        }
        getPicDetails();
    }, [])


    function printDocument() {
        const input = document.getElementById('pic-details');
        html2canvas(input)
          .then((canvas) => {
            const imgData = canvas.toDataURL('image/png');
            const pdf = new jsPDF();
            pdf.addImage(imgData, 'JPEG', 0, 0);
            // pdf.output('dataurlnewwindow');
            pdf.save("download.pdf");
          })
        ;
      }
      const doc = new jsPDF();
      const Foo = document.getElementById('pic-details');

      const save = () => {
        doc.html(ReactDOMServer.renderToStaticMarkup(Foo), {
          callback: () => {
            doc.save("myDocument.pdf");
          }
        });
      };
    




    return (
        <div className="container col-6 mx-auto">
            <button className="btn btn-primary my-4" onClick={save}>Download Picture</button>
            <div id="pic-details">
                <table  className="table table-bordered" >
                    <thead>
                    <tr>
                        <th>Site Location</th>
                        <th>Activity Location</th>
                        <th>Remark</th>
                        <th>Type</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>{picDetails["site_location"]}</td>
                        <td>{picDetails["location"]}</td>
                        <td>{picDetails["remark"]}</td>
                        <td>{picDetails["type"]}</td>
                    </tr>
                    </tbody>
                </table>
                <img id="image" className="img-fluid my-3" src={`${baseUrl}public/uploads/${picDetails["img"]}`} width="700"/>
            </div>
        </div>
    )
}
