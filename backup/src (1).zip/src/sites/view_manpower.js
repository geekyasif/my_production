import React from "react";
import DataTable from "react-data-table-component";
import Checkbox from "@material-ui/core/Checkbox";
import ArrowDownward from "@material-ui/icons/ArrowDownward";
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useParams, useLocation } from "react-router";
import baseUrl from "../components/base_url/baseUrl";
import ExportTableData from "../components/export-table-data/ExportTableData";

// i have to get manpower details by site id and also i have to check api of get manpower

export default function Manpower() {
  let { siteId } = useParams();
  const [manpower, setManpower] = useState([]);

  const sortIcon = <ArrowDownward />;
  const selectProps = { indeterminate: (isIndeterminate) => isIndeterminate };

  const columns = [
    {
      name: "No.",
      selector: (row) => row.id,
    },
    {
      name: "Date",
      selector: (row) => row.date,
    },
    {
      name: "Activity",
      selector: (row) => row.name,
    },
    {
      name: "Total Skilled",
      selector: (row) => row.total_skilled,
    },
    {
      name: "Total Unskilled",
      selector: (row) => row.total_unskilled,
    },
    {
      name: "Edited By",
      selector: (row) => row.edited_by,
    },
    {
      name: "Edited By",
      selector: (row) => row.id,
    },
    {
      name: "Edit",
      selector: (row) => row.id,
      cell: (row) => (
        <Link
          to={`/sites/view_manpower/edit_manpower/${row.id}`}
          className="btn btn-primary btn-sm"
        >
          Edit
        </Link>
      ),
    },
  ];

  useEffect(() => {
    async function fetchManpowerBySiteId() {
      const response = await fetch(`${baseUrl}api/data/getTotalManpower`, {
        method: "POST",
        body: JSON.stringify({ site_id: siteId.toString() }),
      });
      console.log(`${baseUrl}api/data/getTotalManpower`);
      const json = await response.json();
      console.log(json["data"]);
      setManpower(json["data"]);
    }

    fetchManpowerBySiteId();
  }, []);

  return (
    <div className="">
      <h1 className="text-center my-4">Total Manpower</h1>
      <ExportTableData data={manpower} columns={columns} />
      <DataTable
        key={manpower.id}
        pagination
        selectableRowsComponent={Checkbox}
        selectableRowsComponentProps={selectProps}
        sortIcon={sortIcon}
        dense
        columns={columns}
        data={manpower}
      />
    </div>
  );
}
