import React from "react";

export default function AddUser() {
  return (
    <div classNameName="container my-4">
      <div className="row addUserRow my-4">
        <div className="col-lg-4 col-lg-offset-4">
          <h2>Add New User</h2>
          <h5>Please enter the required information below.</h5>
          <hr />
          <form
            action="http://192.168.1.13/panel/user/add"
            className="form-signin"
            method="post"
            accept-charset="utf-8"
          >
            <div className="form-group">
              <input
                type="text"
                name="firstname"
                value=""
                id="firstname"
                placeholder="First Name"
                className="form-control"
              />
            </div>
            <div className="form-group">
              <input
                type="text"
                name="lastname"
                value=""
                id="lastname"
                placeholder="Last Name"
                className="form-control"
              />
            </div>{" "}
            <div className="form-group">
              <input
                type="text"
                name="email"
                value=""
                id="email"
                placeholder="Email"
                className="form-control"
              />
            </div>{" "}
            <div className="form-group">
              <select name="role" className="form-control" id="role">
                <option value="1">Admin</option>
                <option value="2">User</option>
                <option value="3">Subscriber</option>
              </select>
            </div>
            <div className="form-group">
              <input
                type="password"
                name="password"
                value=""
                id="password"
                placeholder="Password"
                className="form-control"
              />
            </div>
            <div className="form-group">
              <input
                type="password"
                name="passconf"
                value=""
                id="passconf"
                placeholder="Confirm Password"
                className="form-control"
              />
            </div>
            <input
              type="submit"
              value="Add"
              className="btn btn-lg btn-primary btn-block"
            />
          </form>
        </div>
      </div>
    </div>
  );
}
