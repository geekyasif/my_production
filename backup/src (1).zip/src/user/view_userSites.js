import React from "react";
import DataTable from "react-data-table-component";
import Checkbox from "@material-ui/core/Checkbox";
import ArrowDownward from "@material-ui/icons/ArrowDownward";
import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import baseUrl from "../components/base_url/baseUrl";
import ExportTableData from "../components/export-table-data/ExportTableData";
import { useParams } from "react-router";

export default function UserSites() {
  let { id } = useParams();

  const [userSites, setUserSites] = useState([]);

  const sortIcon = <ArrowDownward />;
  const selectProps = { indeterminate: (isIndeterminate) => isIndeterminate };

  const columns = [
    {
      name: "No.",
      selector: (row) => row.id,
    },
    {
      name: "Site Name",
      selector: (row) => row.name,
    },
    {
      name: "Site Location",
      selector: (row) => row.location,
    },
    {
      name: "Member Size",
      selector: (row) => row.members,
    },
    {
      name: "User id",
      selector: (row) => row.user_id,
    },
    {
      name: "View Members",
      selector: (row) => row.id,
      cell: (row) => (
        <Link
          className="btn btn-danger btn-sm"
          to={`/sites/view_members/${row.id}`}
        >
          View Members
        </Link>
      ),
    },
    {
      name: "View Manpower",
      selector: (row) => row.id,
      cell: (row) => (
        <Link
          className="btn btn-danger btn-sm"
          to={`/sites/view_manpower/${row.id}`}
        >
          View Manpower
        </Link>
      ),
    },
    {
      name: "Site Pictures",
      selector: (row) => row.id,
      cell: (row) => (
        <Link
          className="btn btn-danger btn-sm"
          to={`/sites/view_sitepictures/${row.id}`}
        >
          View Pictures
        </Link>
      ),
    },
    {
      name: "Stock Details",
      selector: (row) => row.id,
      cell: (row) => (
        <Link
          className="btn btn-danger btn-sm"
          to={`/sites/view_stock/${row.id}`}
        >
          View Stock Details
        </Link>
      ),
    },
    {
      name: "Stock Requests",
      selector: (row) => row.id,
      cell: (row) => (
        <Link
          className="btn btn-danger btn-sm"
          to={`/sites/view_stockrequest/${row.id}`}
        >
          View Requests
        </Link>
      ),
    },
    {
      name: "Attendance",
      selector: (row) => row.id,
      cell: (row) => (
        <Link
          className="btn btn-secondary btn-sm"
          to={`/sites/view_stockrequest/${row.id}`}
        >
          View Attendance
        </Link>
      ),
    },
    {
      name: "Daybook",
      selector: (row) => row.id,
      cell: (row) => (
        <Link
          className="btn btn-danger btn-sm"
          to={`/sites/view_stockrequest/${row.id}`}
        >
          View Daybook
        </Link>
      ),
    },
  ];

  useEffect(() => {
    async function fetchSites() {
      const response = await fetch(`${baseUrl}api/data/getSiteById`, {
        method: "POST",
        body: JSON.stringify({ id: id.toString() }),
      });
      console.log(`${baseUrl}api/data/getSiteById`);
      const json = await response.json();
      console.log(json["data"]);
      if (json["data"]) {
        setUserSites(json["data"]);
      }
    }

    fetchSites();
  }, []);

  return (
    <div className=" my-5">
      <h1 className="mb-5 text-center">User Site List</h1>
      <ExportTableData data={userSites} columns={columns} />
      <DataTable
        key={userSites ? userSites.id : id}
        pagination
        selectableRowsComponent={Checkbox}
        selectableRowsComponentProps={selectProps}
        sortIcon={sortIcon}
        dense
        columns={columns}
        data={userSites ? userSites : []}
      />
    </div>
  );
}
