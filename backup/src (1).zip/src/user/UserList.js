import React from "react";
import DataTable from "react-data-table-component";
import Checkbox from "@material-ui/core/Checkbox";
import ArrowDownward from "@material-ui/icons/ArrowDownward";
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import baseUrl from "../components/base_url/baseUrl";
import ExportTableData from "../components/export-table-data/ExportTableData";

export default function UserList() {
  const [userList, setUserList] = useState([]);

  const sortIcon = <ArrowDownward />;
  const selectProps = { indeterminate: (isIndeterminate) => isIndeterminate };
  const columns = [
    {
      name: "No.",
      selector: (row) => row.id,
    },
    {
      name: "Name",
      selector: (row) => row.first_name,
    },
    {
      name: "Email",
      selector: (row) => row.email,
    },
    {
      name: "Phone",
      selector: (row) => row.last_name,
    },
    {
      name: "Role",
      selector: (row) => row.role,
    },
    {
      name: "Status",
      selector: (row) => row.status,
    },
    {
      name: "Banned",
      selector: (row) => row.banned_users,
    },
    {
      name: "Admin",
      selector: (row) => row.admin,
    },
    {
      name: "Edit",
      selector: (row) => row.id,
      cell: (row) => (
        <Link
          className="btn btn-primary btn-sm"
          to={`/user_list/edit_user/${row.id}`}
        >
          Edit
        </Link>
      ),
    },
    {
      name: "Delete",
      selector: (row) => row.id,
      cell: (row) => (
        <button
          className="btn btn-danger btn-sm"
          onClick={() => deleteUser(row.id)}
        >
          Delete
        </button>
      ),
    },

    {
      name: "Sites",
      selector: (row) => row.id,
      cell: (row) => (
        <Link
          className="btn btn-danger btn-sm"
          to={`/user_list/view_sites/${row.id}`}
        >
          View Sites
        </Link>
      ),
    },
  ];

  const userLists = [];

  useEffect(() => {
    async function fetchSites() {
      const response = await fetch(`${baseUrl}api/data/getAllUsers`, {
        method: "POST",
      });
      console.log(`${baseUrl}api/data/getAllUsers`);
      const json = await response.json();

      json.forEach((data) => {
        userLists.push(data);
      });
      setUserList(userLists);
    }
    fetchSites();
  }, [userLists]);

  async function deleteUser(id) {
    const response = await fetch(`${baseUrl}api/data/deleteUserById`, {
      method: "POST",
      body: JSON.stringify({ id: id }),
    });
    const json = await response.json();
    console.log(json);
    if (json === 1) {
      alert("User Deleted successfully");
    } else {
      alert("Something went wrong plese try again !");
    }
  }

  useEffect(() => {
    async function fetchSites() {
      const response = await fetch(`${baseUrl}api/data/getAllUsers`, {
        method: "POST",
      });
      console.log(`${baseUrl}api/data/getAllUsers`);
      const json = await response.json();
      setUserList(json);
    }

    fetchSites();
  }, []);

  return (
    <div className=" my-4">
      <h1 className="text-center mb-4">Users List</h1>
      <ExportTableData data={userList} columns={columns} />
      <DataTable
        // key={userList.id}
        pagination
        selectableRowsComponent={Checkbox}
        selectableRowsComponentProps={selectProps}
        sortIcon={sortIcon}
        dense
        columns={columns}
        data={userList}
      />
    </div>
  );
}
