<?php
defined('BASEPATH') or exit('No direct script access allowed');

class ApiModel extends CI_Model
{
    /**
     * Get location office on database.
     *
     * @return array
     */

    public function getActivity()
    {
        $this->db->select('*');
        $this->db->from('activity');
        $query = $this->db->get();
        return $query->result();
    }
    public function login($username, $password,$token)
    {
        $this->load->library('password');
        $this->db->select('*');
        $this->db->where('email', $username);
        $query = $this->db->get('users');
        $userInfo = $query->row();
        $count = $query->num_rows();
        if ($count == 1) {
            if (!$this->password->validate_password($password, $userInfo->password)) {
                error_log('Unsuccessful login attempt(' . $username . ')');
                return false;
            }
            $this->MainModel->updateLoginTime($userInfo->id);
            if($token!=null)
            $this->MainModel->updateToken($userInfo->id,$token);
        } else {
            error_log('Unsuccessful login attempt(' . $username . ')');
            return false;
        }
        unset($userInfo->password);
        return $userInfo;
    }

    
    public function uploadActivity($post)
    {
        $string = array(
            'site_location' => $post["site_location"],
            'type' => $post["type"],
            'location' => $post["location"],
            'remark' => $post['remark'],
            'img' => $post['img'],
            'date' => $post['date'],
            'user_id' => (int)$post['user_id'],
            'site_id' => (int)$post['site_id']
        );
        $q = $this->db->insert_string('pic_activity', $string);
        //print($q);
        $this->db->query($q);
        $check = $this->db->insert_id();
        return $check ;
    }
    public function insertLabour($post)
    {


        $string = array(
            'name' => $post['name'],
            'editedby' => $post['editedby'],
            'selection' => 'false',

        );


        $q = $this->db->insert_string('activity', $string);
        $this->db->query($q);
        $check = $this->db->insert_id();
        // $id=$this->db->insert_id();

        return $check;
    }


    public function insertUserInfo($post)
    {
        $this->load->library('password');
        $cleanPost = $this->security->xss_clean($post);
        $hashed = $this->password->create_hash($cleanPost['password']);
        // $hashed=hash('sha256',$post["password"]);	
        $string = array(
            'email' => $post['username'],
            'site_id' => $post['site_id'],
            'admin' => $post['admin'],
            'first_name' => $post['name'],
            'last_name' => $post['mobile'],
            'password' => $hashed,
            'status' => 'approved',
            'banned_users' => 'unban',
            'role' => $post['role'],
        );
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('email', $post['username']); 
        $query = $this->db->get();
        $status=$query->result();
        // print_r($status);
        if( !$status)
       {

            $q = $this->db->insert_string('users', $string);
           $check= $this->db->query($q);
           $check = $this->db->insert_id();
        return $check;
            }
       return 0;
    }


    public function updateUserPass($post)
    {
        $this->load->library('password');
        $cleanPost = $this->security->xss_clean($post);
        $hashed = $this->password->create_hash($cleanPost['password']);
        $data = [
            'password' => $hashed,
        ];
        $this->db->where('last_name', $post["mobile"]);
        $this->db->update('users', $data);
        return ($this->db->affected_rows());
    }
    public function getUsername($post){
        // echo $post;
        // die();
        $this->db->select('email');
        $this->db->where('last_name', $post);
        $query = $this->db->get('users');
        $userInfo = $query->row();
        return $userInfo;
    }

    public function getpicActivity($post)
    {
        $this->db->select('*');
        if ($post['site_id'] != "0")
        $this->db->where('site_id', $post['site_id']);
        if ($post['id'] != "0")
            $this->db->where('id', $post['id']);
        if ($post['type'] != "0") 
            $this->db->where('type', $post['type']);
        if ($post['location'] != "0")
            $this->db->where('location', $post['location']);
            if ($post['date_from'] != "0" &&$post['date_to'] != "0")
            $this->db->where('date BETWEEN "'. date('Y-m-d', strtotime($post['date_from'])).
             '" and "'. date('Y-m-d', strtotime($post['date_to'])).'"');
		
        $this->db->from('pic_activity');
		$this->db->order_by("id","desc");
        $query = $this->db->get();
        return $query->result();
    }



    public function getpicActivityBySiteId($cleanPost){
        $this->db->select('*');
        $this->db->where('site_id', $cleanPost['site_id']);
        $this->db->from('pic_activity');
		$this->db->order_by("id","desc");
        $query = $this->db->get();
        return $query->result();

    }



    public function getLocationArea()
    {
        $this->db->select('*');
        $this->db->from('location');
        $query = $this->db->get();
        return $query->result();
    }
    // ----------------------------------------admin info-----------------------------
    public function adminInfo($post)
    {
        $this->db->select('*');
        $this->db->where('id', $post);
        $query = $this->db->get('users');
        $userInfo = $query->row();
        $count = $query->num_rows();

        if ($count == 1) {
            unset($userInfo->password);
            return $userInfo;
        } else {
            error_log('Unsuccessful login attempt');
            return false;
        }
    }


    public function  insertStock($post)
    {

        $string = array(
            'name' => $post['name'],
            'brand' => $post['brand'],
            'quantity' => $post['quantity'],
            'unit' => $post['unit'],
            'user_id' => $post['user_id'],
            'site_id' => $post['site_id'],
            'date' => $post['date']
        );

        $q = $this->db->insert_string('stock', $string);
        $this->db->query($q);
        $check = $this->db->insert_id();
        return $check;
    }



    public function  insertStockRequest($post)
    {
        $string = array(
            'name' => $post['name'],
            'user' => $post['user'],
            'quantity' => $post['quantity'],
            'brand' => $post['brand'],
            'date' => $post['date'],
            'user_id' => $post['user_id'],
            'site_id' => $post['site_id'],
            'material_id' => $post['material_id']
        );
        $q = $this->db->insert_string('stock_request', $string);
        $this->db->query($q);
        $check = $this->db->insert_id();
        return $check;
    }

    public function  requestFund($post)
    {
        $string = array(
            'site_id' => $post['site_id'],
            'user_id' => $post['user_id'],
            'amount' => $post['amount'],
            'date' => $post['date'],
            'time' => $post['time'],
            'status' => $post['status']
        );
        $q = $this->db->insert_string('fund', $string);
        $this->db->query($q);
        $check = $this->db->insert_id();
        return $check;
    }

    /**
     * Get md5 location office.
     *
     * @return array
     */
    public function getMd5Location()
    {
        $this->db->select('*');
        $this->db->from('md_location');
        $query = $this->db->get();
        return $query->result();
    }

    /**
     * Store location office.
     *
     * @param $post
     * @return bool
     */
    public function insertLocation($post)
    {
        $string = array(
            'lat' => $post['lat'],
            'longt' => $post['longt'],
        );

        $q = $this->db->insert_string('location', $string);
        $this->db->query($q);
        $check = $this->db->insert_id();

        return $check ? true : false;
    }

    /**
     * Delete location office.
     *
     * @return void
     */
    public function deleteTableLocation()
    {
        $this->db->empty_table('location');
    }

    /**
     * Store md5 location office.
     *
     * @param $post
     * @return bool
     */
    public function insertMd5($post)
    {
        $string = array(
            'md5' => $post['md5'],
        );
        $this->db->where('id', 1);
        $this->db->update('md_location', $string);
        $this->db->trans_complete();
        $success = $this->db->affected_rows();
        if ($success) {
            return true;
        }
        return false;
    }

    public function updateFundRequest($post)
    {
        $string = array(
            'status' => $post['status'],
        );
        $this->db->where('id', $post['id']);
        $this->db->update('fund', $string);
        $this->db->trans_complete();
        $success = $this->db->affected_rows();
        if ($success) {
            return true;
        }
        return false;
    }





    // =============== stock section =============================

    /**
     * Get Pending Stock Request Details.
     *
     * @return array
     */
    public function updateStoreRequest($post)
    {
//         print_r($post);
//         die();
        if($post["status"]=="update"||$post["status"]=="remain"){
            $data = array(
                'quantity' => $post['quantity']
            );
            $this->db->where('id', $post['material_id']);
            $this->db->update('stock', $data);
            $this->db->trans_complete();
            if($this->db->affected_rows()<1)
            return false;
        }
		if($post["status"]=="remain"){
        $string = array(
			'quantity' => $post['request']
        );
			$this->db->where('id', $post['id']);
        $this->db->update('stock_request', $string);
        $this->db->trans_complete();
        return $this->db->affected_rows();
		}
		$string = array(
            'status' => $post['status']
        );
        $this->db->where('id', $post['id']);
        $this->db->update('stock_request', $string);
        $this->db->trans_complete();
        return $this->db->affected_rows();
    }
    public function insertConsuption($post)
    {
        // print_r($post);
        // die();
    
       return $this->db->update_batch('stock', $post,"id");

    }
    public function getPendingRequest()
    {
        $this->db->select('*');
        $this->db->from('stock_request');
        $this->db->where('status', 'pending');
        $query = $this->db->get();
        return $query->result();
    }
    public function getFundRequest()
    {

        $this->db->select('*');
        $this->db->order_by("id","desc");
        $this->db->from('fund');
        $this->db->where('status', '0');
        $query = $this->db->get();
        return $query->result();
    }
    public function getPendingRequestBySiteId($site_id){
        $this->db->select('*');
        $this->db->from('stock_request');
        $this->db->where('site_id', $site_id);
        $this->db->where('status', "pending")->or_where('status', "accepted")->or_where('status', "remain");
        $query = $this->db->get();
        return $query->result();
    }
    /**
     * accepting Pending Stock Request Details.
     *
     * @return array
     */
    public function acceptPendingRequest($id)
    {
        $data = [
            'status' => 'approved',
        ];
        $this->db->where('id', $id);
        $this->db->update('stock_request', $data);
        return $this->db->affected_rows();
    }



    /**
     * rejecting Pending Stock Request Details.
     *
     * @return array
     */
    public function rejectPendingRequest($id)
    {
        $data = [
            'status' => 'rejected',
        ];
        $this->db->where('id', $id);
        $this->db->update('stock_request', $data);
        return $this->db->affected_rows();
    }


    /**
     * Get Pending Stock Request Details.
     *
     * @return array
     */
    public function getStockData($site_id)
    {
        $this->db->select('*');
        $this->db->from('stock');
        $this->db->where('site_id', $site_id); 
        $query = $this->db->get();
        return $query->result();
    }

    public function getReceivingData($site_id)
    {
        $this->db->select('*');
        $this->db->from('receiving');
		$this->db->order_by("id","desc");
        $this->db->where('site_id', $site_id); 
        $query = $this->db->get();
        return $query->result();

    }

    public function getReceivingSearchData($site_id,$datefrom,$dateto){
        $this->db->select('*');
        $this->db->from('receiving');
        $this->db->where('site_id', $site_id); 
        $this->db->where('date BETWEEN "'. date('Y-m-d', strtotime($datefrom)). '" and "'. date('Y-m-d', strtotime($dateto)).'"');
        $query = $this->db->get();
        $result = $query->result();
        //print_r($result);
        return $query->result();

    }

    public function checkStockData($id)
    {
        $array = array('id' => $id,
    );
        $this->db->select('quantity');
        $this->db->where($array); 
        $this->db->from('stock');
        $query = $this->db->get();
        $result= $query->result();
        return $result[0]->quantity;
    }
    public function swapAdmin($admin_id,$user_id)
    {
        
        $where = "id=$admin_id  OR id=$user_id";
        $this->db->select('*');
        $this->db->where($where);
        $this->db->from('users');
        $query = $this->db->get();
        $result = $query->result();
        $data1=$result[0];
        $data2=$result[1];
        $tmp= $data1->id;
        $data1->id=$data2->id;
        $data2->id=$tmp;
        $tmp= $data1->role;
        $data1->role=$data2->role;
        $data2->role=$tmp;
        $tmp= $data1->admin;
        $data1->admin=$data2->admin;
        $data2->admin=$tmp;
        $tmp= $data1->site_id;
        $data1->site_id=$data2->site_id;
        $data2->site_id=$tmp;
        $data = array($data1,$data2);
        $this->db->where($where);
        $this->db->delete('users');
        // $data = array($data1, $data2);
        $q = $this->db->insert_batch('users', $data);
        $check = $this->db->affected_rows();
        return $check;
     
    }

    // updating stock request
    public function updateStockRequest($id, $quantity)
    {
        $data = [
            'quantity' => $quantity,
        ];
        $this->db->where('id', $id);
        $this->db->update('stock', $data);
        return $this->db->affected_rows();
    }

    // =============== unit section =============================

    // getting all the units
    public function getUnits()
    {
        $this->db->select('*');
        $this->db->from('unit');
        $query = $this->db->get();
        return $query->result();
    }


    // =============== manpower section =============================

    public function getSiteIdByUserId($id)
    {
        $this->db->select('site_id');
        $this->db->from('users');
        $this->db->where('id', $id);
        $query = $this->db->get();
        return $query->row();
    }

    // inserintg manpower
    public function insertManpower($cleanPost)
    {
        $string = array(
            'name' => $cleanPost['name'],
            'edited_by' => $cleanPost['edited_by'],
            'skilled' => $cleanPost['skilled'],
            'unskilled' => $cleanPost['unskilled'],
            'user_id' => $cleanPost['user_id'],
            'site_id' => $cleanPost['site_id'],
            'date' =>   $cleanPost['date']
        );
// print_r($string);
// die();
        $q = $this->db->insert_string('manpower', $string);
        $this->db->query($q);
        $check = $this->db->affected_rows();
        return $check;
    }

    // inserintg manpower
    public function insertTotalManpower($cleanPost)
    {
        $string = array(
            'total_skilled' => $cleanPost['total_skilled'],
            'total_unskilled' => $cleanPost['total_unskilled'],
            'edited_by' => $cleanPost['edited_by'],
            'site_id' => $cleanPost['site_id'],
            'user_id' => $cleanPost['user_id'],
            'date' => $cleanPost['date'],
        );
        $q = $this->db->insert_string('totalmanpower', $string);
        $this->db->query($q);
        $check = $this->db->affected_rows();
        return $check;
    }


    public function getTotalManpower($site_id)
    {
        $this->db->select('*');
        $this->db->from('totalmanpower');
        $this->db->order_by("id","desc");
        $this->db->where('site_id', $site_id);
        $query = $this->db->get();
        return $query->result();
    }

    public function getManpowerByDate($site_id, $date)
    {
        $filter = array("site_id" => $site_id, 'date' => $date);
        $this->db->select('*');
        $this->db->from('manpower');
        $this->db->order_by("id","desc");
        $this->db->where($filter);
        $query = $this->db->get();
        return $query->result();
    }



    //============================ site model ================================

    public function insertSite($cleanPost)
    {

        $string = array(
            'name' => $cleanPost['name'],
            'location' => $cleanPost['location'],
            'members' => $cleanPost['members'],
            'user_id' => $cleanPost['user_id'],

        );
        $q = $this->db->insert_string('site', $string);
        $this->db->query($q);
        $site_id = $this->db->insert_id();
       return $site_id;
    }

    public function insert_default_item($site_id){

    }
    public function getSiteById($user_id)
    {
        $this->db->select('*');
        $this->db->from('site');
        $this->db->where('user_id', $user_id);
        $query = $this->db->get();
        return $query->result();
    }


    public function getUsersBySiteId($id)
    {
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('site_id', $id);
        $query = $this->db->get();
        $result =  $query->result();
        $final = array();

        foreach ($result as $user) {
            unset($user->password);
            unset($user->role);
            unset($user->last_login);
            unset($user->status);
            unset($user->banned_users);
            unset($user->admin);
            array_push($final, $user);
        }
        return $final;
    }



    // ====================== daybook ===================================
    public function insertReceiving($cleanPost)
    {
        $string = array(
            'by_whom' => $cleanPost["by_whom"],
            'username' => $cleanPost["username"],
            'amount' =>  $cleanPost["amount"],
            'site_id' => $cleanPost["site_id"],
            'user_id' => $cleanPost["user_id"],
            'date' => $cleanPost["date"]

        );
        $q = $this->db->insert_string('receiving', $string);
        $this->db->query($q);
        $check = $this->db->affected_rows();
        return $check;
    }

    


    public function getReceiving($site_id)
    {

        $this->db->select('*');
        $this->db->from('receiving');
        $this->db->where('site_id', $site_id);
        $query = $this->db->get();
        return $query->result();
    }


    // not completed
    public function getTotalReceiving($site_id)
    {
        $this->db->select_sum('amount');
            $this->db->from('receiving');
            $this->db->where('site_id', $site_id);
            $query= $this->db->get();
            $result=$query->result();
        return $result[0];
    }

    // ====================== daybook expenses===================================
    public function insertExpenses($cleanPost)
    {
        $string = array(
            'by_whom' => $cleanPost["by_whom"],
            'username' => $cleanPost["username"],
            'amount' =>  $cleanPost["amount"],
            'site_id' => $cleanPost["site_id"],
            'user_id' => $cleanPost["user_id"],
            'date' => $cleanPost["date"]
        );
        $q = $this->db->insert_string('expenses', $string);
        $this->db->query($q);
        $check = $this->db->affected_rows();
        return $check;
    }


    public function getExpenses($site_id)
    {
        $this->db->select('*');
        $this->db->from('expenses');
		$this->db->order_by("id","desc");
        $this->db->where('site_id', $site_id);
        $query = $this->db->get();
        return $query->result();
    }

    public function getExpensesData($site_id,$datefrom,$dateto){
        $this->db->select('*');
        $this->db->from('expenses');
        $this->db->where('site_id', $site_id); 
        $this->db->where('date BETWEEN "'. date('Y-m-d', strtotime($datefrom)). '" and "'. date('Y-m-d', strtotime($dateto)).'"');
        $query = $this->db->get();
        $result = $query->result();
        //print_r($result);
        return $query->result();

    }

    public function getTotalExpenses($site_id)
    {
            $this->db->select_sum('amount');
            $this->db->from('expenses');
            $this->db->where('site_id', $site_id);
            $query= $this->db->get();
            $result=$query->result();
        return $result[0]; 

    }
    public function getAttendanceBySiteId($site_id)
    {
        $this->db->select('*');
        $this->db->from('attendance');
		$this->db->order_by("id","desc");
        $this->db->where('site_id', $site_id);
        $query = $this->db->get();
        return $query->result();
    }

    public function getAttendanceByDate($site_id,$datefrom,$dateto){
        $this->db->select('*');
        $this->db->from('attendance');
		$this->db->order_by("id","desc");
        $this->db->where('site_id', $site_id); 
        $this->db->where('date BETWEEN "'. date('Y-m-d', strtotime($datefrom)). '" and "'. date('Y-m-d', strtotime($dateto)).'"');
        $query = $this->db->get();
        return $query->result();

    }
	public function getTodayAttendance($date)
    {
        $this->db->select('*');
        $this->db->from('totalmanpower');
		$this->db->order_by("id","desc");
        $this->db->where('date', $date);
        $query = $this->db->get();
        return $query->result();
    }



    // ------------------------ web react js api starts here -------------------------

    public function addNewUser($cleanPost){
        $this->load->library('password');
        $cleanPost = $this->security->xss_clean($cleanPost);
        $hashed = $this->password->create_hash($cleanPost['password']);

        $data = [

            'first_name' => $cleanPost["first_name"],
            'last_name' => $cleanPost["last_name"],
            'email' =>  $cleanPost["email"],
            'role' =>  $cleanPost["role"],
            'status' =>  $cleanPost["status"],
            'banned_users' =>  $cleanPost["banned_users"],
            'site_id' => $cleanPost["site_id"],
            'password' =>  $hashed,

        ];


        $q = $this->db->insert_string('users', $data);
        $this->db->query($q);
        $check = $this->db->insert_id();
        // $id=$this->db->insert_id();

        return $check;


        

    }
   


    public function updateUserDetails($cleanPost){

            $data = [
                'first_name' => $cleanPost["first_name"],
                'last_name' => $cleanPost["last_name"],
                'email' =>  $cleanPost["email"],
            ];
            
            $this->db->where('id', $cleanPost["id"]);
            $this->db->update('users', $data);
            return $this->db->affected_rows();

    }

    public function getAllUsers(){
        $this->db->select('*');
        $this->db->from('users');
        $query = $this->db->get();
        return $query->result();
    }

    public function getUserDetailsById($user_id){

        $this->db->select("*");
        $this->db->from('users');
        $this->db->where("id", $user_id);
        $query = $this->db->get();
        return $query->result();
        
    }

    public function getAdminName($id){

        $this->db->select("first_name");
        $this->db->from('users');
        $this->db->where("id", $id);
        $query = $this->db->get();
        return $query->result();
        
    }

    public function deleteUserById($id){
        $this->db->where('id', $id);
       $check =  $this->db->delete('users');
        if($check){
            return true;
        }else{
            return false;
        }
    }

    public function updateUserById($cleanPost){

        $data = [
            'first_name' => $cleanPost["first_name"],
            'last_name' => $cleanPost["last_name"],
            'email' => $cleanPost["email"],
            'role' => $cleanPost["role"],
            'status' => $cleanPost["status"],
            'banned_users' => $cleanPost["banned_users"],
        ];

        $this->db->where('id', $cleanPost["id"]);
        $this->db->update('users', $data);
        return $this->db->affected_rows();


    }


    public function getUserDetails($id){

        $this->db->select("*");
        $this->db->from('users');
        $this->db->where("id", $id);
        $query = $this->db->get();
        return $query->result();

    }

    public function getManpowerDetails($id){

        $this->db->select("*");
        $this->db->from('manpower');
        $this->db->where("site_id", $id);
        $query = $this->db->get();
        return $query->result();

    }

    public function getStockDetails($id){

        $this->db->select("*");
        $this->db->from('stock');
        $this->db->where("id", $id);
        $query = $this->db->get();
        return $query->result();

    }

    // ban user by admin
    // public function banUser($id, $cleanPost){
    //     $data = [
    //         'banned_users' => $cleanPost,
    //     ];

    //     $this->db->where('id', $id);
    //     $this->db->update('users', $data);
    //     return $this->db->affected_rows();

    // }

    public function getPicDetails($id){
        $this->db->select("*");
        $this->db->from('pic_activity');
        $this->db->where("id", $id);
        $query = $this->db->get();
        return $query->result();
    }















    public function uploadLoginSelfie($post)
    {
        $string = array(
            'name' => $post["name"],
            'attempt' => $post["attempt"],
            'time' => $post["time"],
            'date' => $post['date'],
            'img' => $post['img'],
            'user_id' => (int)$post['user_id'],
            'site_id' => (int)$post['site_id'],
            'longi' =>$post['longi'],
            'lati' => $post['lati'],
            'location' => $post['location']
        );
    // print_r ($arr);
        // die();
        $q = $this->db->insert_string('attendance', $string);
        //print($q);
        $this->db->query($q);
        $check = $this->db->insert_id();
        return $check ? true : false;
    }
    public function getUserByAdminId($admin)
    {
        $this->db->select('id,first_name,site_id');
        $this->db->from('users');
        $this->db->where('admin', $admin);
        $query = $this->db->get();
        return $query->result();
    }
    function banUser($id){
        $data = [
            'banned_users' => 'ban',
        ];
        $this->db->where('id', $id);
        $this->db->update('users', $data);
        $success = $this->db->affected_rows();
        return $success;

    }
    function unBanUser($id){
        $data = [
            'banned_users' => 'unban',
        ];
        $this->db->where('id', $id);
        $this->db->update('users', $data);
        $success = $this->db->affected_rows();
        return $success;

    }



    public function getPicByDate($site_id,$datefrom,$dateto){
        $this->db->select('*');
        $this->db->from('pic_activity');
        $this->db->where('site_id', $site_id); 
        $this->db->where('date BETWEEN "'. date('Y-m-d', strtotime($datefrom)). '" and "'. date('Y-m-d', strtotime($dateto)).'"');
        $query = $this->db->get();
        $result = $query->result();
        //print_r($result);
        return $query->result();

    }


    
}
