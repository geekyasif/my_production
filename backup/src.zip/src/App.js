import "./App.css";
import { Routes, Route, Switch } from "react-router-dom";
import Login from "./login/Login";
import Home from "./home/Home";
import {useNavigate } from 'react-router-dom';

function App() {

  const navigate = useNavigate();
  
  return (
    <div>
      {
      sessionStorage.getItem("isLoggedIn") === "true" 
        ? <Home /> 
        :  <Routes>
        <Route exact path="/login" element={<Login />} />
           <Route  path="/"  redirectTo="/login" element={<Login />} />
        </Routes>
      }

      
    </div>
  );
}

export default App;
