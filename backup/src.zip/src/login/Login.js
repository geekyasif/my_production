import React from "react";
import { useState } from "react";
import NavLogo from "../assets/logo512.png";
import baseUrl from "../components/base_url/baseUrl";
import { useNavigate } from "react-router-dom";
import "./login.css";
import { Link } from "react-router-dom";

export default function Login() {
  const [username, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    const response = await fetch(`${baseUrl}api/data/login`, {
      method: "POST",
      body: JSON.stringify({ username: username, password: password, token: null }),
    });

    const json = await response.json();
    // localstorage ya  session storage
    if (json["status"] === 0) {
      sessionStorage.setItem("isLoggedIn", "true");
      // sessionStorage.setItem("user", JSON.stringify(json));

      sessionStorage.setItem("username", json["full_name"]);
      sessionStorage.setItem("user_id", json["id"]);
      sessionStorage.setItem("email", json["email"]);
      sessionStorage.setItem("phone", json["last_name"]);
      sessionStorage.setItem("role", json["role"]);
      sessionStorage.setItem("admin", json["admin_id"]);
      sessionStorage.setItem("site_id", json["site_id"]);


      navigate("/dashboard");
    } else {
      alert("Inavlid Credential");
    }

    setUserName("");
    setPassword("");

  };

  return (
    <div className="loginMainContainer">
      <div className="container py-4 text-center ">
        <div className="row py-4 ">
          <div className="center-vertical ">
            <div className=" container col-lg-4 shadow-sm bg-light rounded py-3">
              <div className="row">
                <div className="col-md-8">
                  {" "}
                  <h2>VconstructHome</h2>
                  <h5>Please Login.</h5>
                </div>{" "}
                <div className="col-md-4">
                  <img src={NavLogo} width="80" />
                </div>
              </div>
              <hr />
              <form
                onSubmit={handleSubmit}
                className="form-signin"
                method="post"
                accept-charset="utf-8"
              >
                <div className="form-group my-2">
                  <input
                    type="text"
                    name="email"
                    value={username}
                    onChange={(e) => setUserName(e.target.value)}
                    id="email"
                    placeholder="Email"
                    className="form-control"
                  />
                </div>
                <div className="form-group my-2">
                  <input
                    type="password"
                    name="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    id="password"
                    placeholder="Password"
                    className="form-control"
                  />
                </div>
                <div class="d-grid gap-2">
                  <button class="btn btn-primary" type="submit">
                    Let me in!
                  </button>
                </div>
              </form>
              <br />
              <p>
                <small>
                  {" "}
                  Forgot your password?
                  <Link to="/forgot_password">Forgot Password</Link>
                </small>
              </p>
              <hr />
              Copyright© - 2021 | Create by
              <a href="https://vconstructhome.com/"> VconstructHome</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
