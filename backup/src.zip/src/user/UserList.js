import React from "react";
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import baseUrl from "../components/base_url/baseUrl";
import MaterialTable from "material-table";

export default function UserList() {
  const [userList, setUserList] = useState([]);

  const columns = [
    {
      title: "No",
      field: "id",
    },
    {
      title: "Name",
      field: "first_name",
    },
    {
      title: "Email",
      field: "email",
    },
    {
      title: "Phone",
      field: "last_name",
    },
    {
      title: "Role",
      field: "role",
    },
    {
      title: "Status",
      field: "status",
    },
    {
      title: "Banned",
      field: "banned_users",
    },
    {
      title: "Admin",
      field: "admin",
    },
    {
      title: "Edit",
      field: "id",
      render: (rowData) => (
        <Link
          className="btn btn-primary btn-sm"
          to={`/user_list/edit_user/${rowData.id}`}
        >
          Edit
        </Link>
      ),
    },
    {
      title: "Delete",
      field: "id",
      render: (rowData) => (
        <button
          className="btn btn-danger btn-sm"
          onClick={() => deleteUser(rowData.id)}
        >
          Delete
        </button>
      ),
    },

    {
      title: "Sites",
      field: "id",
      render: (rowData) => (
        <Link
          className="btn btn-danger btn-sm my-3"
          to={`/user_list/view_sites/${rowData.id}`}
        >
          View Sites
        </Link>
      ),
    },
  ];

  

  useEffect(() => {
    const userLists = [];
    async function fetchSites() {
      const response = await fetch(`${baseUrl}api/data/getAllUsers`, {
        method: "POST",
      });
      const json = await response.json();

      json.forEach((data) => {
        userLists.push(data);
      });
      setUserList(userLists);
    }
    fetchSites();
  }, );

  async function deleteUser(id) {
    const response = await fetch(`${baseUrl}api/data/deleteUserById`, {
      method: "POST",
      body: JSON.stringify({ id: id }),
    });
    const json = await response.json();
    if (json === 1) {
      alert("User Deleted successfully");
    } else {
      alert("Something went wrong plese try again !");
    }
  }

  useEffect(() => {
    async function fetchSites() {
      const response = await fetch(`${baseUrl}api/data/getAllUsers`, {
        method: "POST",
      });
      const json = await response.json();
      setUserList(json);
    }

    fetchSites();
  }, []);

  return (
    <div className=" my-4">
      <MaterialTable
        title="User List"
        columns={columns}
        data={userList ? userList : []}
        options={{
          exportButton: true,
          sorting: true,
          search: true,
        }}
      />
    </div>
  );
}
