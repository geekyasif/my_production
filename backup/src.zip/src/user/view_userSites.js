import React from "react";
import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import baseUrl from "../components/base_url/baseUrl";
import { useParams } from "react-router";
import MaterialTable from "material-table";

export default function UserSites() {
  let { id } = useParams();

  const [userSites, setUserSites] = useState([]);

  const columns = [
    { title: "No", field: "id" },
    { title: "Site Name", field: "name" },
    { title: "Site Location", field: "location" },
    { title: "Member Size", field: "members" },
    { title: "User id", field: "user_id" },
    {
      title: "View Members",
      field: "id",
      render: (rowData) => (
        <Link
          className="btn btn-danger btn-sm"
          to={`/sites/view_members/${rowData.id}`}
        >
          View Members
        </Link>
      ),
    },

    {
      title: "View Manpower",
      field: "id",
      render: (rowData) => (
        <Link
          className="btn btn-danger btn-sm"
          to={`/sites/view_manpower/${rowData.id}`}
        >
          View Manpower
        </Link>
      ),
    },

    {
      title: "Site Pictures",
      field: "id",
      render: (rowData) => (
        <Link
          className="btn btn-danger btn-sm"
          to={`/sites/view_sitepictures/${rowData.id}`}
        >
          View Pictures
        </Link>
      ),
    },

    {
      title: "Stock Details",
      field: "id",
      render: (rowData) => (
        <Link
          className="btn btn-danger btn-sm my-3"
          to={`/sites/view_stock/${rowData.id}`}
        >
          View Stock
        </Link>
      ),
    },

    {
      title: "Stock Requests",
      field: "id",
      render: (rowData) => (
        <Link
          className="btn btn-danger btn-sm"
          to={`/sites/view_stockrequest/${rowData.id}`}
        >
          View Requests
        </Link>
      ),
    },

    {
      title: "Attendance",
      field: "id",
      render: (rowData) => (
        <Link
          className="btn btn-secondary btn-sm"
          to={`/sites/view_stockrequest/${rowData.id}`}
        >
          View Attendance
        </Link>
      ),
    },

    {
      title: "Daybook",
      field: "id",
      render: (rowData) => (
        <Link
          className="btn btn-danger btn-sm"
          to={`/sites/view_stockrequest/${rowData.id}`}
        >
          View Daybook
        </Link>
      ),
    },
  ];

  useEffect(() => {
    async function fetchSites() {
      const response = await fetch(`${baseUrl}api/data/getSiteById`, {
        method: "POST",
        body: JSON.stringify({ id: id.toString() }),
      });
      const json = await response.json();
      if (json["data"]) {
        setUserSites(json["data"]);
      }
    }

    fetchSites();
  },);

  return (
    <div className=" mx-2 my-5">
      <MaterialTable
        title="User Sites"
        columns={columns}
        data={userSites ? userSites : []}
        options={{
          exportButton: true,
          sorting: true,
          search: true,
        }}
      />
    </div>
  );
}
