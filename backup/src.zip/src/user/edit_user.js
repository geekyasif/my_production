import React from "react";
import { useEffect, useState } from "react";
import baseUrl from "../components/base_url/baseUrl";
import { useParams } from "react-router";
import { Link, useNavigate } from "react-router-dom";

export default function EditUser() {
  let { userId } = useParams();
  const navigate = useNavigate();
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("");
  const [banned_users, setBannedUsers] = useState("");
  const [status, setStatus] = useState("");

  async function fetchUserDetail() {

    const response = await fetch(`${baseUrl}api/data/getUserDetailsById`, {
      method: "POST",
      body: JSON.stringify({ id: userId }),
    });

    const json = await response.json();
    console.log(json["data"])
    setFirstName(json["data"][0]["first_name"]);
    setLastName(json["data"][0]["last_name"]);
    setEmail(json["data"][0]["email"]);
    setRole(json["data"][0]["role"]);
    setBannedUsers(json["data"][0]["banned_users"]);
    setStatus(json["data"][0]["status"]);
  
  }



  useEffect(() => {
    fetchUserDetail();
  },[]);

  const updateUser = async (e) => {
    e.preventDefault();

    console.log(firstName); 
    console.log(lastName); 
    console.log(email); 
    console.log(role); 
    console.log(status); 
    console.log(banned_users); 

    const response = await fetch(`${baseUrl}api/data/updateUserById`, {
      method: "POST",
      body: JSON.stringify({
        id: userId,
        first_name: firstName,
        last_name: lastName,
        email: email,
        role: role,
        status: status,
        banned_users: banned_users,
      }),
    });
    const json = await response.json();


    if (json === 1) {
      alert("User updated successfully");
      navigate('/user_list')
    } else {
      alert("Something went wrong plese try again !");
    }

  };

  return (
    <div className="container mx-auto">
      <div className="row">
        <div className="col-lg-6 col-lg-offset-4">
          <h2>Edit User</h2>
          <h5>
            Hi <span>{sessionStorage.getItem("username")}</span>, <br />
            Edit user.
          </h5>
          <hr />
          <form className="form-signin" onSubmit={updateUser}>
            <div className="form-group">
              <input
                type="text"
                name="firstname"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                id="firstname"
                placeholder="First Name"
                className="form-control"
              />
            </div>
            <div className="form-group">
              <input
                type="text"
                name="lastname"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                id="lastname"
                placeholder="Last Name"
                className="form-control"
              />
            </div>
            <div className="form-group">
              <input
                type="text"
                name="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                id="email"
                placeholder="Last Name"
                className="form-control"
              />
            </div>
            <div className="form-group">
              <select
                name="role"
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="form-control"
                id="role"
              >
                <option value="1">Admin</option>
                <option value="2">User</option>
                <option value="3">Subscriber</option>
              </select>
            </div>
            <div className="form-group">
              <select
                name="banned_users"
                value={banned_users}
                onChange={(e) => setBannedUsers(e.target.value)}
                className="form-control"
                id="banned_user"
              >
                <option value="ban">Ban</option>
                <option value="unban">Un Ban</option>
              </select>
            </div>
            <div className="form-group">
              <select
                name="status"
                value={status}
                onChange={(e) => setStatus(e.target.value)}
                className="form-control"
                id="status"
              >
                <option value="pending">Pending</option>
                <option value="approved">Approved</option>
              </select>
            </div>
            <input
              type="submit"
              value="Submit"
              className="btn btn-lg btn-primary btn-block"
            />
            <Link
              to={`/user_list`}
              className="btn btn-default btn-lg btn-block"
            >
              Cancel
            </Link>
          </form>
        </div>
      </div>
    </div>
  );
}
