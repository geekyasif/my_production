import React from "react";
import { useState } from "react";
import { Link } from "react-router-dom";
import baseUrl from "../components/base_url/baseUrl";

export default function AddUser() {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [site_id, setSiteId] = useState("0");
  const [role, setRole] = useState("1");
  const [banned_users, setBannedUsers] = useState("unban");
  const [status, setStatus] = useState("approved");
  const [password, setPassword] = useState("");
  const [cpassword, setCPassword] = useState("");

  const addNewUser = async (e) => {
    e.preventDefault();

    if (password === cpassword) {
      const response = await fetch(`${baseUrl}api/data/addNewUser`, {
        method: "POST",
        body: JSON.stringify({
          first_name: firstName,
          last_name: lastName,
          email: email,
          role: role,
          status: status,
          site_id: site_id,
          banned_users: banned_users,
          password: password,
        }),
      });

      const json = response.json();
      if (json["status"]) {
        alert("new user added successfully");
      } else {
        alert("Some error occured while creating new user");
      }

      console.log(
        password,
        role,
        status,
        banned_users,
        firstName,
        lastName,
        email,
         site_id,
         password
      );
      setPassword("");
      setCPassword("");
      setRole("");
      setStatus("");
      setBannedUsers("");
      setFirstName("");
      setLastName("");
      setEmail("");
    } else {
      alert("Password does not matched");
    }
  };

  return (
    <div className="container mx-auto my-4">
      <div className="row">
        <div className="col-lg-6 col-lg-offset-4">
          <h2>Add New User</h2>
          <hr />
          <form className="row form-signin needs-validation" onSubmit={addNewUser}>
            <div className="col-6">
              <div className="form-group has-validation">
                <label for="text" class="form-label">
                  Full Name
                </label>
                <input
                  type="text"
                  name="firstname"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  id="firstname"
                  placeholder="Full Name"
                  className="form-control"
                />
                 <div class="invalid-feedback">
                  Please enter Full Name.
                </div>
              </div>
            </div>
            <div className="col-6">
              <div className="form-group has-validation">
                <label for="text" class="form-label">
                  Phone
                </label>
                <input
                  type="text"
                  name="lastname"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  id="lastname"
                  placeholder="Phone"
                  className="form-control"
                />
                 <div class="invalid-feedback">
                    Please enter phone number.
                </div>
              </div>
            </div>

            <div className="form-group has-validation">
              <label for="exampleInputEmail1" class="form-label">
                Email address
              </label>
              <input
                type="text"
                name="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                id="email"
                placeholder="Email"
                className="form-control"
              />
               <div class="invalid-feedback">
                  Please enter valid email address
                </div>
            </div>

            <div className="col-6">
              <div className="form-group has-validation">
                <label for="text" class="form-label">
                  Status
                </label>
                <select
                  name="status"
                  value={status}
                  onChange={(e) => setStatus(e.target.value)}
                  className="form-control"
                  id="status"
                >
                  <option value="pending">Pending</option>
                  <option value="approved">Approved</option>
                </select>
                <div class="invalid-feedback">
                  Please select status
                </div>
                
              </div>
            </div>
            <div className="col-6">
              <div className="form-group has-validation">
                <label for="text" class="form-label">
                  Ban Status
                </label>
                <select
                  name="banned_users"
                  value={banned_users}
                  onChange={(e) => setBannedUsers(e.target.value)}
                  id="banned_user"
                  className="form-control"
                >
                  <option value="ban">Ban</option>
                  <option value="unban">Un Ban</option>
                </select>
                
                <div class="invalid-feedback">
                  Please select ban status
                </div>

              </div>
            </div>
            <div className="col-6">
              <div className="form-group has-validation">
                <label for="text" class="form-label">
                  Role
                </label>
                <select
                  name="role"
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  className="form-control"
                  id="role"
                >
                  <option value="1">Admin</option>
                  <option value="2">User</option>
                  <option value="3">Subscriber</option>
                </select>

                <div class="invalid-feedback">
                  Please select role
                </div>


              </div>
            </div>
            <div className="col-6">
              <div className="form-group ">
                <label for="text" class="form-label">
                  Site Id
                </label>
                <input
                  name="site_id"
                  value={site_id}
                  onChange={(e) => setSiteId(e.target.value)}
                  className="form-control"
                  id="site_id"
                  placeholder="Site Id"
                  className="form-control"
                />
                <small>
                  Site Id only required for user role for admin role bydefault
                  it is 0
                </small>
              </div>
            </div>

            <div className="form-group">
              <label for="text" class="form-label">
                Password
              </label>
              <input
                type="password"
                name="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                id="password"
                placeholder="Password"
                className="form-control"
              />
            </div>

            <div className="form-group">
              <label for="text" class="form-label">
                Confirm Password
              </label>
              <input
                type="password"
                name="cpassword"
                value={cpassword}
                onChange={(e) => setCPassword(e.target.value)}
                id="cpassword"
                placeholder="Confirm Password"
                className="form-control"
              />
            </div>

            <input
              type="submit"
              value="Submit"
              className="btn btn-lg btn-primary btn-block"
            />
            <Link
              to={`/user_list`}
              className="btn btn-default btn-lg btn-block"
            >
              Cancel
            </Link>
          </form>
        </div>
      </div>
    </div>
  );
}
