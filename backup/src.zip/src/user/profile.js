import React from "react";
import {useState, useEffect} from "react";
import "./profile.css";
import baseUrl from '../components/base_url/baseUrl'

export default function Profile() {
  const id = sessionStorage.getItem("user_id");
  const[firstName, setFirstName] = useState(sessionStorage.getItem("username"))
  const[lastName, setLastName] = useState(sessionStorage.getItem("phone"))
  const[email, setEmail] = useState(sessionStorage.getItem("email"))


  useEffect(() => {

    async function fetchUserDetail() {
      const response = await fetch(`${baseUrl}api/data/getUserDetailsById`, {
        method: "POST",
        body: JSON.stringify({ id: id }),
      });
      const json = await response.json();
      setFirstName(json["data"][0]["first_name"]);
      setLastName(json["data"][0]["last_name"]);
      setEmail(json["data"][0]["email"]);
    }

    fetchUserDetail();

  },[])


    const updateProfile = async(e)=> {

      e.preventDefault();
          
          const response = await fetch(`${baseUrl}api/data/updateUserDetails`, {
            method: "POST",
            body: JSON.stringify({ id: id, first_name: firstName, last_name: lastName, email: email }),
          });
          const json = await response.json();
          if (json["status"]) {
            alert("Profile Updated Successfully")
          }else{
            alert("Profile not Updated.")
          }

    }





  return (
    <div>
      <div className="container px-4 col-lg-4 col-sm-12 my-5">
        <div className="row gx-5">
          <div className="col">
            <h2>Edit Profile</h2>
            <h5>Edit your profile.</h5>
            <hr />

            <form className="form-signin" onSubmit={updateProfile}>
              <div className="form-group">
                <input
                  type="text"
                  name="firstname"
                  onChange={(e)=> setFirstName(e.target.value)}
                  value={firstName}
                  id="firstname"
                  placeholder="First Name"
                  className="form-control"
                />
              </div>
              <div className="form-group my-3">
                <input
                  type="text"
                  name="lastname"
                  onChange={(e)=> setLastName(e.target.value)}
                  value={lastName}
                  id="lastname"
                  placeholder="Last Name"
                  className="form-control"
                />
              </div>
              <div className="form-group">
                <input
                  type="email"
                  name="email"
                  onChange={(e)=> setEmail(e.target.value)}
                  value={email}
                  id="email"
                  placeholder="Email"
                  className="form-control"
                />
              </div>

              {/* <Accordion defaultActiveKey="0" className="my-3">
                <Accordion.Item eventKey="1">
                  <Accordion.Header>
                    {" "}
                    <small>Change Password?</small>
                  </Accordion.Header>
                  <Accordion.Body>
                    <input
                      type="password"
                      name="password"
                      value={password}
                      onChange={(e)=> setPassword(e.target.value)}
                      id="password"
                      placeholder="Password"
                      className="form-control"
                    />
                    <input
                      type="password"
                      name="passconf"
                      value={cpassword}
                      onChange={(e)=> setCPassword(e.target.value)}
                      id="passconf"
                      placeholder="Confirm Password"
                      className="form-control my-3"
                    />
                  </Accordion.Body>
                </Accordion.Item>
              </Accordion> */}
              <input type="submit" value="Update" className="btn btn-primary" />
            </form>
          </div>
        </div>
      </div>

      <div className="profileContainer ">
        <div className="row profileRow">
          <div className="col-sm-12"></div>
        </div>
      </div>
    </div>
  );
}
