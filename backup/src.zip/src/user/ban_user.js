import React from "react";
import { useState } from "react";
import { useParams } from "react-router-dom";
import baseUrl from "../components/base_url/baseUrl";

export default function BanUser() {
  const { userId } = useParams();
  const [status, setStatus] = useState("");

  const banUser = async (e) => {
    e.preventDefault();

    const request = await fetch(`${baseUrl}api/data/banUser`, {
      method: "POST",
      body: JSON.stringify({ id: userId.toString(), status: status }),
    });

    const json = request.json();
  };

  return (
    <div className="container mx-auto col-sm-12">
      <h1>Ban or Unban user {userId}</h1>
      <form onSubmit={banUser}>
        <div className="form-group">
          <select
            className="form-control"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            <option selected value="ban">
              Ban
            </option>
            <option value="unban">Unban</option>
          </select>
        </div>
        <button className="btn btn-primary" type="submit">
          Submit
        </button>
      </form>
    </div>
  );
}
