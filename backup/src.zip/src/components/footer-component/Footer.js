import React from 'react'

export default function Footer() {

    const footer = {
        position: "fixed",
        left: "0",
        bottom: "0",
        width: "100%",
        backgroundColor: "red",
        color: "white",
        textAlign: "center"
    }
    return (
        <div>
            <footer className="footer mt-auto py-3 bg-light sticky-bottom">
                <div className="container">
                    <span className="text-muted" href="https://admin.vconstructhome.com/">VconstructHome.com</span>
                </div>
            </footer>
        </div>
    )
}
