import React from 'react'
import { useParams } from 'react-router'
import baseUrl from "../components/base_url/baseUrl"
import {useState, useEffect } from 'react';

export default function EditStock() {
    let {id} = useParams();
    // const [stockDetails, setStockDetails] = useState([]);
    const[name, setName] = useState('');
    const[brand, setBrand] = useState('');
    const[unit, setUnit] = useState('');
    const[quantity, setQuantity] = useState('');
    


    useEffect(() => {
        async function fetchUserDetails() {
          const response = await fetch(`${baseUrl}api/data/getStockDetails`, {
            method: "POST",
            body: JSON.stringify({id : id})
          });
          const json = await response.json();
          const data = json["data"][0]
          setName(data["name"]);
          setBrand(data["brand"]);
          setQuantity(data["quantity"]);
          setUnit(data["unit"]);
          
        }
    
        fetchUserDetails();
      },);
    

    return (
        <div>
            <h2 className="text-center my-4">Edit Stock</h2>
            <div class="row">
        <div class="col-lg-4 col-lg-offset-4 mx-auto">
          <h2>Edit Stock</h2>
          <hr />
          <form
            class="form-signin"
          >
            <div class="form-group">
              <input
                type="text"
                name="name"
                value={name}
                onChange={(e)=> setName(e.target.value)}
                id="stock-name"
                class="form-control"
              />
            </div>{" "}
            <div class="form-group">
              <input
                type="text"
                name="brand"
                value={brand}
                onChange={(e)=> setBrand(e.target.value)}
                id="stock-brand"
                class="form-control"
              />
            </div>{" "}
            <div class="form-group">
              <input
                type="text"
                name="stock-unit"
                value={unit}
                onChange={(e)=> setUnit(e.target.value)}
                id="stock-unit"
                class="form-control"
              />
            </div>
            <div class="form-group">
              <input
                type="text"
                name="stock-quantity"
                value={quantity}
                onChange={(e)=> setQuantity(e.target.value)}
                id="stock-quantity"
               
                class="form-control"
              />
            </div>
            <input
              type="submit"
              value="Submit"
              class="btn btn-lg btn-primary btn-block"
            />
          </form>
        </div>
      </div>
        </div>
    )
}
