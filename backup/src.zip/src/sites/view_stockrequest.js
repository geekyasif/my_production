import React from "react";
import { useState, useEffect } from "react";
import { useParams } from "react-router";
import baseUrl from "../components/base_url/baseUrl";
import MaterialTable from "material-table";
// site picture api is pending
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

export default function StockRequest() {
  let { siteId } = useParams();
  const [stockRequests, setStockRequests] = useState([]);
  const doc = new jsPDF();
  const columns = [
    {
      title: "No",
      field: "id",
    },
    {
      title: "Name",
      field: "name",
    },
    {
      title: "Quantity",
      field: "quantity",
    },
    {
      title: "User",
      field: "user",
    },
    {
      title: "Date",
      field: "date",
    },
    {
      title: "Status",
      field: "status",
    },
  ];

  // fetching all the data using api
  useEffect(() => {
    async function fetchUsersBySiteId() {
      const response = await fetch(
        `${baseUrl}api/data/getPendingRequestBySiteId`,
        {
          method: "POST",
          body: JSON.stringify({ site_id: siteId.toString() }),
        }
      );
      const json = await response.json();
      if (json["status"]) {
        setStockRequests(json["data"]);
      }
    }

    fetchUsersBySiteId();
  });

  function printDocument() {
    const input = document.getElementById("stock-request");
    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL("jpg");
      doc.addImage(imgData, "jpg", 15, 40, 180, 180);
      doc.save("download.pdf");
    });
  }

  return (
    <div>
      <button className="btn btn-primary my-4" onClick={printDocument}>
        Download Pdf
      </button>
      <div className=" my-4 mx-2" id="stock-request">
        <MaterialTable
          title="Stock Requests"
          columns={columns}
          data={stockRequests ? stockRequests : []}
          options={{
            exportButton: true,
            sorting: true,
            search: true,
          }}
        />
      </div>
    </div>
  );
}
