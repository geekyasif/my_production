import React from 'react'
import { useParams } from 'react-router'
import baseUrl from "../components/base_url/baseUrl"
import {useState, useEffect } from 'react';

export default function EditMember() {
    let {id} = useParams();
    const[firstName, setFirstName] = useState('');
    const[lastName, setLastName] = useState('');
    const[email, setEmail] = useState('');


    useEffect(() => {
        async function fetchUserDetails() {
          const response = await fetch(`${baseUrl}api/data/getUserDetails`, {
            method: "POST",
            body: JSON.stringify({id : id})
          });
          const json = await response.json();
          setFirstName(json['data'][0]["first_name"])
          setLastName(json['data'][0]["last_name"])
          setEmail(json['data'][0]["email"])
        }

        fetchUserDetails();
      },[]);
    



      const updateMember =  async (e)=> {
          
        e.preventDefault();
          
          const response = await fetch(`${baseUrl}api/data/updateUserDetails`, {
            method: "POST",
            body: JSON.stringify({ id: id, first_name: firstName, last_name: lastName, email: email }),
          });
          const json = await response.json();
          if (json["data"]) {
            alert("Profile Updated Successfully")
          }else{
            alert("Profile not Updated.")
          }

      }

      



    return (
        <div>
            <h2 className="text-center my-4">Edit Member</h2>
            <div className="row">
        <div className="col-lg-4 col-lg-offset-4 mx-auto">
          <h2>Edit Member</h2>
          <hr />
          <form
          onSubmit={updateMember}
            className="form-signin"
          >
            <div className="form-group">
              <input
                type="text"
                name="firstname"
                value={firstName}
                onChange={ (e) => setFirstName(e.target.value)}
                id="firstname"
        
                className="form-control"
              />
            </div>{" "}
            <div className="form-group">
              <input
                type="text"
                name="lastname"
                value={lastName}
                onChange={(e)=> setLastName(e.target.value)}
                id="lastname"
  
                className="form-control"
              />
            </div>{" "}
            <div className="form-group">
              <input
                type="text"
                name="lastname"
                value={email}
                onChange={(e)=> setEmail(e.target.value)}
                id="lastname"

                className="form-control"
              />
            </div>
            <input
              type="submit"
              value="Submit"
              className="btn btn-lg btn-primary btn-block"
            />
          </form>
        </div>
      </div>
        </div>
    )
}
