import React from "react";
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useParams } from "react-router";
import baseUrl from "../components/base_url/baseUrl";
import MaterialTable from "material-table";
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

// i have to get manpower details by site id and also i have to check api of get manpower

export default function Manpower() {
  let { siteId } = useParams();
  const [manpower, setManpower] = useState([]);
  const user_id = sessionStorage.getItem("user_id");
  const doc = new jsPDF();
  const columns = [
    {
      title: "No",
      field: "id",
    },
    {
      title: "No",
      field: "date",
    },
    {
      title: "Activity",
      field: "name",
    },
    {
      title: "Total Skilled",
      field: "skilled",
    },
    {
      title: "Total Unskilled",
      field: "unskilled",
    },
    {
      title: "Edited By",
      field: "edited_by",
    },
    // {
    //   title: "Edit",
    //   field: "id",
    //   render: (rowData) => (
    //     <Link
    //       to={`/sites/view_manpower/edit_manpower/${rowData.id}`}
    //       className="btn btn-primary btn-sm my-3"
    //     >
    //       Edit
    //     </Link>
    //   ),
    // },
  ];

  useEffect(() => {
    async function fetchManpowerBySiteId() {
      const response = await fetch(`${baseUrl}api/data/getManpowerDetails`, {
        method: "POST",
        body: JSON.stringify({ id: siteId.toString(), user_id: user_id }),
      });
      const json = await response.json();
      if (json["status"]) {
        setManpower(json["data"]);
      }
    }

    fetchManpowerBySiteId();
  });


  
  function printDocument() {
    const input = document.getElementById('manpower');
    html2canvas(input)
      .then((canvas) => {
        const imgData = canvas.toDataURL("jpg");
        doc.addImage(imgData,  "jpg", 15, 40, 180, 180);
        doc.save("download.pdf");
      });
  
  }



  return (
    <div>
           <button className="btn btn-primary my-4" onClick={printDocument}>Download Pdf</button>
            <div id="pic-details"></div>
      <div className="mx-2 my-5 " id="manpower">
        <MaterialTable

          title="Sites"
          columns={columns}
          data={manpower}
          options={{
            exportButton: true,
            sorting: true,
            search: true,
          }}
        />
      </div>
    </div>
  );
}
