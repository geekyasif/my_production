import React from "react";
import { useState, useEffect,componentDidMount } from "react";
import { Link } from "react-router-dom";
import { useParams } from "react-router";
import MaterialTable from "material-table";
import jsPDF from "jspdf";
import baseURL from "../components/base_url/baseUrl";
import image from "../assets/logo512.png";
// import DatePicker from "react-datepicker";
// import "react-datepicker/dist/react-datepicker.css";
import { saveAs } from "file-saver";
import DatePicker from "react-date-picker";
// site picture api is pending
import img from '../assets/logo512.png'


export default function SitePictures() {
  let { siteId } = useParams();
  const [pictures, setPictures] = useState([]);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [url, setUrl] = useState("");

  const columns = [
    {
      title: "No",
      field: "id",
    },
    {
      title: "Site Location",
      field: "site_location",
    },
    {
      title: "Type",
      field: "type",
    },
    {
      title: "Activity",
      field: "location",
    },
    {
      title: "Remark",
      field: "remark",
    },
    {
      title: "Date & Time",
      field: "date",
    },
    {
      title: "Pictures",
      field: "img",
      render: (rowData) => (
        <img
          alt="site pic"
          className="img-fluid"
          src={`${baseURL}public/uploads/${rowData.img}`}
        />
      ),
    },
    // {
    //   title: "Picture Details",
    //   field: "id",
    //   render: (rowData) => (
    //     <Link
    //       className="btn btn-danger btn-sm"
    //       to={`/sites/view_pic_details/${rowData.id}`}
    //     >
    //       View Picture
    //     </Link>
    //   ),
    // },
    {
      title: "Picture Details",
      field: "img",
      render: (rowData) => (
        <button
          className="btn btn-danger btn-sm"
          onClick={async () => {
            const response = await fetch(`${baseURL}api/data/getPicDetails`, {
              method: "POST",
              body: JSON.stringify({ id: rowData.id }),
            });
            const json = await response.json();
            if (json["status"]) {
              console.log(json["data"]);
              saveAs(`${json["data"]}`, "sitePic.pdf")
            }
          }}
        >
          View / Download
        </button>
      ),
    },
    {
      title: "Picture Details",
      field: "img",
      render: (rowData) => (
        <a href={img} download
          // className="btn btn-danger btn-sm"
          // onClick={async () => {
          //   const response = await fetch(`${baseURL}api/data/getPicDetails`, {
          //     method: "POST",
          //     body: JSON.stringify({ id: rowData.id }),
          //   });
          //   const json = await response.json();
          //   if (json["status"]) {
          //     console.log(json["data"]);
          //     saveAs(`${json["data"]}`, "sitePic.pdf")
          //   }
          // }}
        >
          View / Download new
        </a>
      ),
    },
  ];

  useEffect(() => {
    async function fetchUsersBySiteId() {
      const response = await fetch(
        `${baseURL}api/data/getpicActivityBySiteId`,
        {
          method: "POST",
          body: JSON.stringify({ site_id: siteId.toString() }),
        }
      );
      const json = await response.json();
      if (json["status"]) {
        setPictures(json["data"]);
      }
    }

    fetchUsersBySiteId();
  }, []);

  const getDataByDate = async (e) => {
    e.preventDefault();
    const response = await fetch(`${baseURL}api/data/getPicByDate`, {
      method: "POST",
      body: JSON.stringify({
        site_id: siteId.toString(),
        datefrom: startDate,
        dateto: endDate,
      }),
    });
    const json = await response.json();
    console.log(json["data"]);

    if (json["status"]) {
      setPictures(json["data"]);
    }

    setStartDate("");
    setEndDate("");

    console.log(startDate);
    console.log(endDate);
  };


  return (
    <div>
    
      <div className="col-lg-6 col-sm-12 container border py-3 mt-2">
      
      <h5 className="text-center">Filter By Date</h5>
      <hr/>
        <form onSubmit={getDataByDate}>
          <div className="row ">
            <div className="col"> 
            <div className="row">
              <div className="col-2 mr-2 mt-3"> <label >To</label></div>
              <div className="col">              
                <input
                  type="date"
                  value={startDate}
                  className="form-control"
                  placeholder="2021-11-05"
                  onChange={(date) => setStartDate(date.target.value)}
                />
              </div>
            </div>

            </div>
            <div className="col"> 
            <div className="row">
              <div className="col-2 me-2 mt-3"> From </div>
              <div class="col">
                <input
                  className="form-control "
                  type="date"
                  placeholder="2021-11-25"
                  value={endDate}
                  onChange={(date) => setEndDate(date.target.value)}
                />
              </div>
            </div>

            </div>
            <div className="col">
            <div className="row">
              <div class="col">
                <button className="btn btn-primary mt-2" type="submit">
                  Search
                </button>
              </div>
            </div>
            </div>
 
           
          </div>
        </form>
      </div>
      <div className=" mx-2 my-4">
        <MaterialTable
          title="Sites"
          columns={columns}
          data={pictures}
          options={{
            exportButton: true,
            sorting: true,
            search: true,
          }}
        />
      </div>
    </div>
  );
}
