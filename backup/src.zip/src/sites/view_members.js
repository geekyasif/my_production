import React from "react";
import { useState, useEffect } from "react";
import { useParams } from "react-router";
import baseUrl from "../components/base_url/baseUrl";
import MaterialTable from "material-table";
import { Link } from "react-router-dom";
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';


export default function Members() {
  let { siteId } = useParams();
  const [members, setMembers] = useState([]);
  const doc = new jsPDF();
  const columns = [
    {
      title: "No",
      field: "id",
    },
    {
      title: "Name",
      field: "first_name",
    },
    {
      title: "Email",
      field: "email",
    },
    {
      title: "Phone Number",
      field: "last_name",
    },
    {
      title: "Edit",
      field: "id",
      render: (rowData) => (
        <Link
          to={`/sites/view_members/edit_member/${rowData.id}`}
          className="btn btn-primary btn-sm my-3"
        >
          Edit
        </Link>
      ),
    },
  ];

  useEffect(() => {
    async function fetchUsersBySiteId() {
      const response = await fetch(`${baseUrl}api/data/getUsersBySiteId`, {
        method: "POST",
        body: JSON.stringify({ id: siteId.toString() }),
      });
      const json = await response.json();
      if (json["status"]) {
        setMembers(json["data"]);
      }
    }

    fetchUsersBySiteId();
  },);

  function printDocument() {
    const input = document.getElementById('members');
    html2canvas(input)
      .then((canvas) => {
        const imgData = canvas.toDataURL("jpg");
        doc.addImage(imgData,  "jpg", 15, 40, 180, 180);
        doc.save("download.pdf");
      });
  
  }



  return (
    <div>
        <button className="btn btn-primary my-4" onClick={printDocument}>Download Pdf</button>
            <div id="pic-details"></div>
      <div className="mx-2 my-4" id="members">
      <MaterialTable
        title="Member List"
        columns={columns}
        data={members ? members : []}
        options={{
          exportButton: true,
          sorting: true,
          search: true,
        }}
      />
    </div>
    </div>
  );
}
